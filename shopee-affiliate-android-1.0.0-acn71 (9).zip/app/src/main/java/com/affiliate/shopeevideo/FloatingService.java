package com.affiliate.shopeevideo;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

/**
 * Edge quick tab: a small tab on the screen edge, visible from any app.
 * Tap it for a game-space-style quick card (snap / full app / hide).
 * The camera button snaps the screen and opens the maker with the trim
 * tool. Stop it from the app's edge toggle or from the notification.
 *
 * The tab sits right on the edge and opens with a tap, can be dragged
 * up/down, and can be moved to the left or right edge from the app's
 * App tab (side + height persist).
 */
public class FloatingService extends Service {

    public static volatile boolean isRunning = false;

    private static final int NOTIFY_ID = 7701;
    private static final String CHANNEL = "edge_panel";
    private static final String ACTION_STOP = "com.affiliate.shopeevideo.EDGE_STOP";
    private static final String ACTION_REPOSITION = "com.affiliate.shopeevideo.EDGE_REPOSITION";
    private static final String ACTION_SNAP_GO = "com.affiliate.shopeevideo.SNAP_GO";
    private static final String ACTION_SNAP_NOW = "com.affiliate.shopeevideo.SNAP_NOW";
    private static final String ACTION_PICKED = "com.affiliate.shopeevideo.PICK_RESULT";
    private static final String PREFS = "edge_panel";
    /* Snap handoff: the maker picks this file up on next resume. */
    private static final String KEY_SNAP = "pending_snap";
    private static final String SNAP_FILE = "pending_snap.jpg";
    private static final String KEY_SIDE = "side";
    private static final String KEY_YF = "yf";
    /** Tab sits right on the physical edge: it opens with a tap. */
    private static final float EDGE_INSET_DP = 0f;

    private WindowManager wm;
    private View stick;
    private WindowManager.LayoutParams stickParams;
    private android.media.projection.MediaProjection projection;
    private android.hardware.display.VirtualDisplay vdisplay;
    private android.media.ImageReader snapReader;
    private volatile boolean snapping = false;
    private int snapRc = 0;
    private Intent snapGrant = null;
    private boolean snapArmed = false;
    private volatile boolean expectStop = false;
    private String snapErr = "";
    private android.app.Notification fgNote;
    private LinearLayout panel;
    private WindowManager.LayoutParams panelParams;
    private WebView web;
    private ValueCallback<Uri[]> fileChooser;
    private int pickSeq = 0;
    private int currentPickId = 0;
    private BroadcastReceiver pickReceiver;

    @Override
    public void onCreate() {
        super.onCreate();
        isRunning = true;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        startAsForeground();
        registerPickReceiver();
        showStick();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (intent != null && ACTION_REPOSITION.equals(intent.getAction())) {
            removeStick();
            if (panel == null) showStick();
            return START_STICKY;
        }
        if (intent != null && ACTION_SNAP_GO.equals(intent.getAction())) {
            onSnapGrant(intent.getIntExtra("rc", 0),
                    (Intent) intent.getParcelableExtra("data"));
            if (panel == null && stick == null) showStick();
            return START_STICKY;
        }
        if (intent != null && ACTION_SNAP_NOW.equals(intent.getAction())) {
            snapNow();
            return START_STICKY;
        }
        if (stick == null && panel == null) showStick();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        try { unregisterReceiver(pickReceiver); } catch (Throwable ignored) {}
        pickReceiver = null;
        removeStick();
        removePanel();
        teardownProjection();
        try { stopForeground(true); } catch (Throwable ignored) {}
        isRunning = false;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    /* ---------- foreground ---------- */

    private void startAsForeground() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null && Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel(CHANNEL,
                        "Edge quick panel", NotificationManager.IMPORTANCE_LOW);
                try { nm.createNotificationChannel(ch); } catch (Throwable ignored) {}
            }
            Intent open = new Intent(this, MainActivity.class);
            open.setAction(Intent.ACTION_MAIN);
            open.addCategory(Intent.CATEGORY_LAUNCHER);
            PendingIntent openPi = PendingIntent.getActivity(this, 1, open,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Intent stop = new Intent(this, FloatingService.class);
            stop.setAction(ACTION_STOP);
            PendingIntent stopPi = PendingIntent.getService(this, 2, stop,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification.Builder b = new Notification.Builder(this, CHANNEL)
                    .setContentTitle("Video maker edge tab")
                    .setContentText("Tap the tab: snap, full app, hide")
                    .setSmallIcon(android.R.drawable.ic_menu_share)
                    .setContentIntent(openPi)
                    .addAction(android.R.drawable.ic_menu_share, "Hide panel", stopPi)
                    .setOngoing(true);
            Notification n = b.build();
            fgNote = n;
            try { stopForeground(true); } catch (Throwable ignored) {}
            assertFgType(android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } catch (Throwable t) {
            try {
                Toast.makeText(this, "Edge panel could not start (" + t + ")",
                        Toast.LENGTH_LONG).show();
            } catch (Throwable ignored) {}
            try { stopSelf(); } catch (Throwable ignored) {}
        }
    }

    /** (Re)declare the runtime foreground-service type (API 29+ needs it explicit). */
    private void assertFgType(int type) {
        try {
            if (fgNote == null) return;
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFY_ID, fgNote, type);
            else startForeground(NOTIFY_ID, fgNote);
        } catch (Throwable t) {
            try {
                Toast.makeText(this, "Edge panel blocked by system (" + t + ")",
                        Toast.LENGTH_LONG).show();
            } catch (Throwable ignored) {}
        }
    }

    /* ---------- stick + panel ---------- */

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private String prefSide() {
        try {
            return getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_SIDE, "right");
        } catch (Throwable t) { return "right"; }
    }

    private void showStick() {
        if (stick != null) return;
        if (!Settings.canDrawOverlays(this)) {
            toast("Allow 'display over other apps' for the edge panel");
            return;
        }
        try {
            final boolean left = "left".equals(prefSide());
            android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
            float yf = 0.5f;
            try { yf = getSharedPreferences(PREFS, MODE_PRIVATE).getFloat(KEY_YF, 0.5f); }
            catch (Throwable ignored) {}
            if (yf < 0.05f) yf = 0.05f;
            else if (yf > 0.95f) yf = 0.95f;

            TextView s = new TextView(this);
            s.setText(left ? "›" : "‹");
            s.setTextColor(0xFFFFFFFF);
            s.setTextSize(22);
            s.setGravity(Gravity.CENTER);
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0xFFE75D8A);
            if (left) bg.setCornerRadii(new float[]{0, 0, 28, 28, 28, 28, 0, 0});
            else bg.setCornerRadii(new float[]{28, 28, 0, 0, 0, 0, 28, 28});
            s.setBackground(bg);
            s.setAlpha(0.92f);
            final WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                    dp(24), dp(96),
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT);
            p.gravity = (left ? Gravity.LEFT : Gravity.RIGHT) | Gravity.CENTER_VERTICAL;
            p.x = dp(EDGE_INSET_DP);
            p.y = Math.round((yf - 0.5f) * dm.heightPixels);
            s.setOnTouchListener(new View.OnTouchListener() {
                float dX, dY;
                int sY;
                boolean drag;
                @Override public boolean onTouch(View v, MotionEvent e) {
                    try {
                        if (e.getAction() == MotionEvent.ACTION_DOWN) {
                            dX = e.getRawX(); dY = e.getRawY();
                            sY = stickParams != null ? stickParams.y : 0;
                            drag = false;
                        } else if (e.getAction() == MotionEvent.ACTION_MOVE) {
                            if (stickParams == null) return true;
                            int dy = (int) (e.getRawY() - dY);
                            if (!drag && Math.hypot(e.getRawX() - dX, dy) > dp(8)) drag = true;
                            if (drag) {
                                stickParams.y = sY + dy;
                                wm.updateViewLayout(stick, stickParams);
                            }
                        } else if (e.getAction() == MotionEvent.ACTION_UP) {
                            if (drag && stickParams != null) {
                                try {
                                    android.util.DisplayMetrics m =
                                            getResources().getDisplayMetrics();
                                    float f = (float) stickParams.y / (float) m.heightPixels + 0.5f;
                                    if (f < 0.05f) f = 0.05f;
                                    else if (f > 0.95f) f = 0.95f;
                                    getSharedPreferences(PREFS, MODE_PRIVATE)
                                            .edit().putFloat(KEY_YF, f).apply();
                                } catch (Throwable ignored) {}
                            } else {
                                expand();
                            }
                        } else if (e.getAction() == MotionEvent.ACTION_CANCEL) {
                            drag = false;
                        }
                    } catch (Throwable ignored) {}
                    return true;
                }
            });
            stick = s;
            stickParams = p;
            wm.addView(stick, p);
        } catch (Throwable t) {
            toast("Edge panel blocked by system");
        }
    }

    private void removeStick() {
        try {
            if (stick != null) wm.removeView(stick);
        } catch (Throwable ignored) {}
        stick = null;
        stickParams = null;
    }

    private void expand() {
        if (panel != null) return;
        removeStick();
        try {
            // Game-space style: a small quick-action card, not a mini app.
            final int pw = dp(232);

            LinearLayout root = new LinearLayout(this);
            root.setOrientation(LinearLayout.VERTICAL);
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0xFF1B1B22);
            bg.setCornerRadius(28);
            bg.setStroke(2, 0xFF3A3A48);
            root.setBackground(bg);

            int pad = dp(8);
            root.setPadding(pad, pad, pad, pad);
            TextView title = new TextView(this);
            title.setText("Video maker");
            title.setTextColor(0xFFF5F3EE);
            title.setTextSize(15);
            title.setGravity(Gravity.CENTER);
            title.setPadding(0, dp(4), 0, dp(2));
            LinearLayout btnRow = new LinearLayout(this);
            btnRow.setOrientation(LinearLayout.HORIZONTAL);
            btnRow.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams bw = new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            Button snap = new Button(this);
            snap.setText("📸");
            snap.setTextSize(22);
            snap.setTextColor(0xFFF5F3EE);
            snap.setBackgroundColor(0x00000000);
            snap.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    try {
                        Intent i = new Intent(FloatingService.this, FloatingService.class);
                        i.setAction(ACTION_SNAP_NOW);
                        startService(i);
                    } catch (Throwable ignored) {}
                }
            });
            Button open = new Button(this);
            open.setText("Full");
            open.setTextSize(15);
            open.setTextColor(0xFFF5F3EE);
            open.setBackgroundColor(0x00000000);
            open.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    try {
                        Intent i = new Intent(FloatingService.this, MainActivity.class);
                        i.setAction(Intent.ACTION_MAIN);
                        i.addCategory(Intent.CATEGORY_LAUNCHER);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(i);
                    } catch (Throwable ignored) {}
                }
            });
            Button hide = new Button(this);
            hide.setText("–");
            hide.setTextSize(22);
            hide.setTextColor(0xFFF5F3EE);
            hide.setBackgroundColor(0x00000000);
            hide.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { collapse(); }
            });
            btnRow.addView(snap, bw);
            btnRow.addView(open, bw);
            btnRow.addView(hide, bw);
            root.addView(title);
            root.addView(btnRow);

            panel = root;
            panelParams = new WindowManager.LayoutParams(
                    pw, WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT);
            panelParams.gravity = Gravity.RIGHT | Gravity.CENTER_VERTICAL;
            panelParams.x = dp(4);
            if (Build.VERSION.SDK_INT >= 26) {
                panelParams.setTitle("Video maker quick card");
            }
            root.setOnTouchListener(new View.OnTouchListener() {
                float lastX, lastY;
                @Override public boolean onTouch(View v, MotionEvent e) {
                    try {
                        if (e.getAction() == MotionEvent.ACTION_DOWN) {
                            lastX = e.getRawX(); lastY = e.getRawY();
                        } else if (e.getAction() == MotionEvent.ACTION_MOVE) {
                            panelParams.x += (int) (e.getRawX() - lastX);
                            panelParams.y += (int) (e.getRawY() - lastY);
                            lastX = e.getRawX(); lastY = e.getRawY();
                            wm.updateViewLayout(panel, panelParams);
                        }
                    } catch (Throwable ignored) {}
                    return true;
                }
            });
            wm.addView(panel, panelParams);
        } catch (Throwable t) {
            removePanel();
            showStick();
            toast("Could not open card");
        }
    }

    private void collapse() {
        removePanel();
        showStick();
    }

    private void removePanel() {
        try {
            if (panel != null) wm.removeView(panel);
        } catch (Throwable ignored) {}
        panel = null;
        panelParams = null;
        try {
            if (web != null) web.destroy();
        } catch (Throwable ignored) {}
        web = null;
        fileChooser = null;
    }

    /* ---------- floating WebView ---------- */

    private WebView buildWebView(final int initScale) {
        final WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        try {
            String ua = s.getUserAgentString();
            if (ua != null && ua.contains("; wv")) s.setUserAgentString(ua.replace("; wv", ""));
        } catch (Throwable ignored) {}
        /* Wide panel showing the fixed 510 layout, same scale math as the app. */
        try { w.setInitialScale(initScale); } catch (Throwable ignored) {}
        w.addJavascriptInterface(new PanelSaveBridge(), "AndroidSave");
        w.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent,
                                        String contentDisposition, String mimeType,
                                        long contentLength) {
                if (url != null && url.startsWith("blob:")) pullBlobToBridge(w, url);
                else enqueueHttp(url);
            }
        });
        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return false; }
            @Override
            public void onPageFinished(WebView v, String url) {
                super.onPageFinished(v, url);
                enforceFixedViewport(v);
            }
        });
        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView v, String url, String message, JsResult result) {
                try { toast(String.valueOf(message)); } catch (Throwable ignored) {}
                try { result.confirm(); } catch (Throwable ignored) {}
                return true;
            }
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileChooser != null) {
                    try { fileChooser.onReceiveValue(null); } catch (Throwable ignored) {}
                }
                fileChooser = cb;
                try {
                    String[] mimes = null;
                    try { mimes = p.getAcceptTypes(); } catch (Throwable ignored) {}
                    currentPickId = ++pickSeq;
                    Intent i = new Intent(FloatingService.this, PickerTrampoline.class);
                    i.putExtra("id", currentPickId);
                    i.putExtra("mime", mimes);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } catch (Throwable t) {
                    fileChooser = null;
                    try { cb.onReceiveValue(null); } catch (Throwable ignored) {}
                }
                return true;
            }
        });
        w.loadUrl("file:///android_asset/www/index.html");
        return w;
    }

    private void enforceFixedViewport(WebView v) {
        if (v == null) return;
        try {
            v.evaluateJavascript(
                    "(function(){try{var m=document.querySelector('meta[name=viewport]');"
                            + "if(!m){m=document.createElement('meta');m.setAttribute('name','viewport');"
                            + "(document.head||document.documentElement).appendChild(m);}"
                            + "m.setAttribute('content','width=510, user-scalable=no, viewport-fit=cover');"
                            + "return 1;}catch(e){return 0;}})();", null);
        } catch (Throwable ignored) {}
    }

    private void registerPickReceiver() {
        try {
            pickReceiver = new BroadcastReceiver() {
                @Override public void onReceive(Context ctx, Intent intent) {
                    if (intent == null || !ACTION_PICKED.equals(intent.getAction())) return;
                    try {
                        int id = intent.getIntExtra("id", 0);
                        if (id != currentPickId || fileChooser == null) return;
                        ValueCallback<Uri[]> cb = fileChooser;
                        fileChooser = null;
                        String u = intent.getStringExtra("uri");
                        if (u == null || u.length() == 0) cb.onReceiveValue(null);
                        else cb.onReceiveValue(new Uri[]{ Uri.parse(u) });
                    } catch (Throwable t) {
                        try { fileChooser.onReceiveValue(null); } catch (Throwable ignored) {}
                        fileChooser = null;
                    }
                }
            };
            IntentFilter f = new IntentFilter(ACTION_PICKED);
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(pickReceiver, f, Context.RECEIVER_NOT_EXPORTED);
            else registerReceiver(pickReceiver, f);
        } catch (Throwable ignored) {}
    }

    /* ---------- downloads in the panel ---------- */

    private void pullBlobToBridge(final WebView w, final String blobUrl) {
        if (w == null || blobUrl == null) return;
        try {
            String q = blobUrl.replace("\\", "\\\\").replace("'", "\\'");
            String js = "(function(){try{fetch('" + q + "').then(function(r){return r.blob();}).then(function(b){"
                    + "var fr=new FileReader();"
                    + "fr.onload=function(){try{"
                    + "var parts=String(fr.result).split(',');"
                    + "AndroidSave.saveBlobData(parts.length>1?parts[1]:'');}catch(e){}};"
                    + "fr.readAsDataURL(b);}).catch(function(){});}catch(e){}})();";
            w.evaluateJavascript(js, null);
        } catch (Throwable ignored) {}
    }

    private void enqueueHttp(String url) {
        try {
            android.app.DownloadManager dm =
                    (android.app.DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            if (dm == null) { toast("Download service unavailable"); return; }
            android.app.DownloadManager.Request req =
                    new android.app.DownloadManager.Request(Uri.parse(url));
            req.setNotificationVisibility(
                    android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            try {
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                        Uri.parse(url).getLastPathSegment());
            } catch (Throwable ignored) {}
            dm.enqueue(req);
            toast("Downloading…");
        } catch (Throwable t) {
            toast("Download failed");
        }
    }

    private class PanelSaveBridge {
        @JavascriptInterface
        public void saveVideo(final String base64, final String filename) {
            saveBase64(base64, filename);
        }
        @JavascriptInterface
        public void saveBlobData(final String base64) {
            saveBase64(base64, "affiliate-video.webm");
        }
    }

    private void saveBase64(final String base64, final String filename) {
        final String name = (filename == null || filename.length() == 0) ? "affiliate-video.webm" : filename;
        new Thread(new Runnable() {
            @Override public void run() {
                final boolean ok = writeToDownloads(base64, name);
                try {
                    android.os.Handler h = new android.os.Handler(getMainLooper());
                    h.post(new Runnable() {
                        @Override public void run() {
                            toast(ok ? ("Saved: " + name) : "Save failed");
                        }
                    });
                } catch (Throwable ignored) {}
            }
        }).start();
    }

    private boolean writeToDownloads(String base64, String name) {
        if (base64 == null || base64.length() == 0) return false;
        byte[] data;
        try { data = Base64.decode(base64, Base64.DEFAULT); }
        catch (Throwable t) { return false; }
        if (Build.VERSION.SDK_INT >= 29) {
            ContentResolver cr = getContentResolver();
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
            cv.put(MediaStore.Downloads.MIME_TYPE, "video/webm");
            cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            Uri uri = null;
            OutputStream out = null;
            try {
                uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (uri == null) return false;
                out = cr.openOutputStream(uri);
                if (out == null) return false;
                out.write(data);
                out.flush();
                return true;
            } catch (Throwable t) {
                try { if (uri != null) cr.delete(uri, null, null); } catch (Throwable ignored) {}
                return false;
            } finally {
                try { if (out != null) out.close(); } catch (Throwable ignored) {}
            }
        } else {
            if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) return false;
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            try {
                if (!dir.exists()) dir.mkdirs();
                FileOutputStream fos = new FileOutputStream(new File(dir, name));
                try {
                    fos.write(data);
                    fos.flush();
                } finally {
                    try { fos.close(); } catch (Throwable ignored) {}
                }
                return true;
            } catch (Throwable t) { return false; }
        }
    }

    /* ---------- one-tap screen snap (MediaProjection stills) ---------- */

    /** System grant arrived: remember it; if a snap was waiting, take it now. */
    private void onSnapGrant(int rc, Intent data) {
        try {
            if (data != null) { snapRc = rc; snapGrant = data; }
            if (snapArmed) {
                snapArmed = false;
                if (snapGrant != null) snapNow();
                else toast("Permission not granted");
            } else {
                toast("Snap ready — tap 📸 to capture");
            }
        } catch (Throwable ignored) {}
    }

    /**
     * Build a throwaway capture session per tap (a kept-alive projection is
     * what kept dying between grant and snap). The foreground
     * mediaProjection type is asserted BEFORE creating the virtual display —
     * newer Android refuses the opposite order.
     */
    private boolean ensureProjection() {
        teardownProjection();
        snapErr = "";
        try {
            if (snapGrant == null) { snapErr = "no permission yet"; return false; }
            try {
                if (Build.VERSION.SDK_INT >= 29) {
                    assertFgType(android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                            | android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
                }
            } catch (Throwable t) { snapErr = "foreground type refused"; return false; }
            android.media.projection.MediaProjectionManager mpm =
                    (android.media.projection.MediaProjectionManager)
                            getSystemService(MEDIA_PROJECTION_SERVICE);
            if (mpm == null) { snapErr = "no capture service"; return false; }
            projection = mpm.getMediaProjection(snapRc, snapGrant);
            if (projection == null) { snapErr = "grant rejected"; return false; }
            android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
            int w = dm.widthPixels, h = dm.heightPixels;
            snapReader = android.media.ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2);
            vdisplay = projection.createVirtualDisplay("affsnap", w, h, dm.densityDpi,
                    android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    snapReader.getSurface(), null, null);
            try {
                projection.registerCallback(
                        new android.media.projection.MediaProjection.Callback() {
                            @Override public void onStop() {
                                boolean self = expectStop;
                                expectStop = false;
                                if (!self) {
                                    snapGrant = null;
                                    teardownProjection();
                                }
                            }
                        }, new android.os.Handler(getMainLooper()));
            } catch (Throwable ignored) {}
            return true;
        } catch (Throwable t) {
            teardownProjection();
            snapErr = shortErr(t);
            return false;
        }
    }

    private String shortErr(Throwable t) {
        try {
            String s = String.valueOf(t);
            if (s.length() > 110) s = s.substring(0, 110);
            return s;
        } catch (Throwable ignored) { return "unknown"; }
    }

    private void teardownProjection() {
        try { if (vdisplay != null) vdisplay.release(); } catch (Throwable ignored) {}
        vdisplay = null;
        try { if (snapReader != null) snapReader.close(); } catch (Throwable ignored) {}
        snapReader = null;
        try { expectStop = true; if (projection != null) projection.stop(); }
        catch (Throwable ignored) {}
        projection = null;
    }

    private void snapNow() {
        try {
            if (snapping) return;
            if (snapGrant == null) {
                snapArmed = true;
                try {
                    Intent i = new Intent(this, SnapPermissionActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } catch (Throwable t) {
                    snapArmed = false;
                    toast("Open the app once, then retry");
                }
                return;
            }
            if (panel == null) { toast("Open the edge tab first"); return; }
            snapping = true;
            try { panel.setVisibility(View.INVISIBLE); } catch (Throwable ignored) {}
            new Thread(new Runnable() {
                @Override public void run() {
                    try { Thread.sleep(400); } catch (Throwable ignored) {}
                    String s = null;
                    String err = "";
                    try {
                        if (ensureProjection()) s = grabSnap();
                        else err = snapErr;
                    } catch (Throwable t) { err = shortErr(t); }
                    try { teardownProjection(); } catch (Throwable ignored) {}
                    final String fs = s;
                    final String fe = err;
                    try {
                        new android.os.Handler(getMainLooper()).post(new Runnable() {
                            @Override public void run() {
                                try { if (panel != null) panel.setVisibility(View.VISIBLE); }
                                catch (Throwable ignored) {}
                                snapping = false;
                                if (fs == null || fs.length() == 0) {
                                    if (snapGrant == null) {
                                        toast("Permission expired — tap 📸 once more");
                                    } else if (fe.length() > 0) {
                                        toast("Snap failed (" + fe + ")");
                                    } else {
                                        toast("Snap failed — try again");
                                    }
                                    return;
                                }
                                deliverSnap(fs);
                            }
                        });
                    } catch (Throwable t) { snapping = false; }
                }
            }).start();
        } catch (Throwable t) { snapping = false; }
    }

    private String grabSnap() {
        android.media.Image img = null;
        try {
            for (int i = 0; i < 40; i++) {
                try { img = snapReader.acquireLatestImage(); } catch (Throwable ignored) {}
                if (img != null) break;
                try { Thread.sleep(100); } catch (Throwable ignored) {}
            }
            if (img == null) return null;
            int w = img.getWidth(), h = img.getHeight();
            android.media.Image.Plane p0 = img.getPlanes()[0];
            java.nio.ByteBuffer buf = p0.getBuffer();
            int rowStride = p0.getRowStride(), pixStride = p0.getPixelStride();
            android.graphics.Bitmap bmp = android.graphics.Bitmap.createBitmap(
                    Math.max(1, rowStride / Math.max(1, pixStride)), h,
                    android.graphics.Bitmap.Config.ARGB_8888);
            bmp.copyPixelsFromBuffer(buf);
            android.graphics.Bitmap cropped =
                    android.graphics.Bitmap.createBitmap(bmp, 0, 0, w, h);
            if (cropped != bmp) { try { bmp.recycle(); } catch (Throwable ignored) {} }
            java.io.ByteArrayOutputStream os = new java.io.ByteArrayOutputStream();
            cropped.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, os);
            try { cropped.recycle(); } catch (Throwable ignored) {}
            return Base64.encodeToString(os.toByteArray(), Base64.NO_WRAP);
        } catch (Throwable t) {
            return null;
        } finally {
            try { if (img != null) img.close(); } catch (Throwable ignored) {}
        }
    }

    private void deliverSnap(String b64) {
        try {
            byte[] data = Base64.decode(b64, Base64.NO_WRAP);
            if (data == null || data.length == 0) { toast("Snap failed — try again"); return; }
            java.io.File f = new java.io.File(getCacheDir(), SNAP_FILE);
            java.io.FileOutputStream fos = new java.io.FileOutputStream(f);
            try {
                fos.write(data);
                fos.flush();
            } finally {
                try { fos.close(); } catch (Throwable ignored) {}
            }
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_SNAP, true).apply();
            try {
                Intent i = new Intent(this, MainActivity.class);
                i.setAction(Intent.ACTION_MAIN);
                i.addCategory(Intent.CATEGORY_LAUNCHER);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Throwable ignored) {}
            toast("Snap saved — opening the maker");
        } catch (Throwable t) {
            toast("Snap failed");
        }
    }

    private void toast(String msg) {
        try { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show(); }
        catch (Throwable ignored) {}
    }
}
