package com.affiliate.shopeevideo;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

/**
 * Shopee Affiliate Video Maker, packaged: the batch-maker page in a WebView.
 *
 * Display is fixed at 520 dp wide on every device and every smallest-width
 * setting (same approach as LitReader): the wide viewport honors the page's
 * width=520 rule and overview mode scales that fixed layout to fit the
 * screen. Immersive sticky fullscreen + edge-to-edge are on via manifest
 * flags below (com.affiliate.shopeevideo.IMMERSIVE / EDGE_TO_EDGE).
 *
 * The page renders videos with canvas.captureStream + MediaRecorder, which
 * produces blob: URLs that a WebView cannot download by itself — the
 * AndroidSave bridge receives them as base64 and writes them to Downloads.
 * Regular https downloads (e.g. the Android bundle zip) go through
 * DownloadManager.
 */
public class MainActivity extends Activity {

    private WebView web;
    private ValueCallback<Uri[]> fileChooser;
    private boolean immersive;
    private long lastBackPress = 0;
    private Toast backToast;
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;

    private static final int REQ_FILE = 1001;
    private static final int REQ_STORAGE = 1002;
    private String pendingB64 = null;
    private String pendingName = null;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);

        immersive = metaBool("com.affiliate.shopeevideo.IMMERSIVE", false);
        boolean edge = metaBool("com.affiliate.shopeevideo.EDGE_TO_EDGE", false);
        boolean dark = metaBool("com.affiliate.shopeevideo.DARK_MODE", false);
        boolean desktop = metaBool("com.affiliate.shopeevideo.DESKTOP_SITE", false);

        if (edge) applyEdgeToEdge();

        web = new WebView(this);
        web.setFitsSystemWindows(false);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        /* Honor the page's `width=520` viewport so the layout stays fixed at
           520 CSS px on every device and every smallest-width (dp) setting.
           Without the wide viewport the WebView ignores the width rule and
           lays out at the device width instead. Overview mode then scales
           the fixed 520 layout to fit the screen. */
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setAllowFileAccessFromFileURLs(true);
        if (desktop) {
            s.setUserAgentString("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36");
        } else {
            try {
                String ua = s.getUserAgentString();
                if (ua != null && ua.contains("; wv")) s.setUserAgentString(ua.replace("; wv", ""));
            } catch (Throwable ignored) {}
        }
        if (dark) applyDark(s);
        /* First paint already at the 520-fit scale: without this the page
           first lays out at scale 1 (device width) and only shrinks to the
           fixed 520 layout seconds later when overview mode kicks in. */
        try {
            android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
            float dpW = dm.widthPixels / dm.density;
            int pct = Math.round(dpW * 100f / 520f);
            if (pct < 10) pct = 10;
            else if (pct > 500) pct = 500;
            web.setInitialScale(pct);
        } catch (Throwable ignored) {}

        setContentView(web);
        if (immersive) applyImmersive();
        setupInsetBridge();

        web.addJavascriptInterface(new SaveBridge(), "AndroidSave");

        web.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent,
                                        String contentDisposition, String mimeType,
                                        long contentLength) {
                if (url != null && url.startsWith("blob:")) {
                    pullBlobToBridge(url);
                } else {
                    enqueueHttpDownload(url);
                }
            }
        });

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return false;
            }
            @Override
            public void onPageFinished(WebView v, String url) {
                super.onPageFinished(v, url);
                enforceFixedViewport(v);
                pushStoredInsets();
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                try {
                    if (customView != null) {
                        try { callback.onCustomViewHidden(); } catch (Throwable ignored) {}
                        return;
                    }
                    customView = view;
                    customCb = callback;
                    FrameLayout decor = (FrameLayout) getWindow().getDecorView();
                    decor.addView(customView, new FrameLayout.LayoutParams(
                            FrameLayout.LayoutParams.MATCH_PARENT,
                            FrameLayout.LayoutParams.MATCH_PARENT));
                    if (web != null) web.setVisibility(View.GONE);
                } catch (Throwable t) {
                    try { callback.onCustomViewHidden(); } catch (Throwable ignored) {}
                }
            }
            @Override
            public void onHideCustomView() {
                hideCustomView();
            }
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileChooser != null) {
                    try { fileChooser.onReceiveValue(null); } catch (Throwable ignored) {}
                }
                fileChooser = cb;
                try {
                    Intent i = p.createIntent();
                    startActivityForResult(i, REQ_FILE);
                } catch (Throwable t) {
                    fileChooser = null;
                    try { cb.onReceiveValue(null); } catch (Throwable ignored) {}
                }
                return true;
            }
        });

        if (saved != null) {
            web.restoreState(saved);
        } else {
            web.loadUrl(appStartUrl());
        }
    }

    /**
     * The layout is fixed at 520 CSS px on every smallest-width (dp) setting:
     * the wide-viewport flags in onCreate honor the page's width=520 viewport
     * and overview mode scales that fixed layout to fit the screen. This
     * repairs at runtime any bundled page that ever ships without the width
     * rule, by creating or correcting the viewport meta after every load.
     */
    private void enforceFixedViewport(WebView v) {
        if (v == null) return;
        try {
            v.evaluateJavascript(
                    "(function(){try{var m=document.querySelector('meta[name=viewport]');"
                            + "if(!m){m=document.createElement('meta');m.setAttribute('name','viewport');"
                            + "(document.head||document.documentElement).appendChild(m);}"
                            + "var c=m.getAttribute('content')||'';"
                            + "if(!/(^|,)\\s*width\\s*=\\s*520(\\s|,|$)/.test(c)){"
                            + "m.setAttribute('content','width=520, user-scalable=no, viewport-fit=cover');}"
                            + "return window.innerWidth+'x'+window.innerHeight;}catch(e){return 'err';}})();",
                    new ValueCallback<String>() {
                        @Override public void onReceiveValue(String value) { /* layout readout; nothing to do */ }
                    });
        } catch (Throwable ignored) {}
    }

    /** System-bar insets pushed into the page as --aff-inset-top/bottom CSS px. */
    private int insetTopCss = 0, insetBottomCss = 0;

    private void setupInsetBridge() {
        if (web == null) return;
        try {
            web.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
                @Override public android.view.WindowInsets onApplyWindowInsets(View v, android.view.WindowInsets insets) {
                    try { pushInsetsToPage(insets); } catch (Throwable ignored) {}
                    return v.onApplyWindowInsets(insets);
                }
            });
            web.requestApplyInsets();
        } catch (Throwable ignored) {}
    }

    private void pushInsetsToPage(android.view.WindowInsets insets) {
        try {
            android.view.WindowInsets root = null;
            try { root = getWindow().getDecorView().getRootWindowInsets(); } catch (Throwable ignored) {}
            if (root == null) root = insets;
            if (root == null) return;
            int topPx, bottomPx;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets stb = root.getInsets(android.view.WindowInsets.Type.statusBars());
                android.graphics.Insets nvb = root.getInsets(android.view.WindowInsets.Type.navigationBars());
                android.graphics.Insets tap = root.getInsets(android.view.WindowInsets.Type.tappableElement());
                topPx = Math.max(stb.top, tap.top);
                bottomPx = Math.max(nvb.bottom, tap.bottom);
            } else {
                topPx = root.getStableInsetTop();
                bottomPx = root.getStableInsetBottom();
            }
            pushInsetsPxToPage(topPx, bottomPx);
        } catch (Throwable ignored) {}
    }

    private void pushInsetsPxToPage(int topPx, int bottomPx) {
        if (web == null) return;
        int viewW = 0;
        try { viewW = web.getWidth(); } catch (Throwable ignored) {}
        if (viewW <= 0) {
            try { viewW = getResources().getDisplayMetrics().widthPixels; } catch (Throwable ignored) {}
        }
        if (viewW <= 0) return;
        double k = 520.0 / (double) viewW;
        insetTopCss = (int) Math.round(topPx * k);
        insetBottomCss = (int) Math.round(bottomPx * k);
        pushStoredInsets();
    }

    private void pushStoredInsets() {
        if (web == null) return;
        final int t = insetTopCss, b = insetBottomCss;
        final String js = "(function(){try{document.documentElement.style.setProperty('--aff-inset-top','"
                + t + "px');document.documentElement.style.setProperty('--aff-inset-bottom','"
                + b + "px');return 1;}catch(e){return 0;}})();";
        try { web.evaluateJavascript(js, null); } catch (Throwable ignored) {}
    }

    private void applyEdgeToEdge() {
        try {
            Window w = getWindow();
            w.addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            if (Build.VERSION.SDK_INT >= 28) {
                WindowManager.LayoutParams a = w.getAttributes();
                a.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
                w.setAttributes(a);
            }
            if (Build.VERSION.SDK_INT >= 30) {
                getWindow().setDecorFitsSystemWindows(false);
            } else {
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
            }
        } catch (Throwable ignored) {}
    }

    private void applyImmersive() {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                if (getWindow().getInsetsController() != null) {
                    getWindow().getInsetsController().hide(
                            android.view.WindowInsets.Type.statusBars()
                                    | android.view.WindowInsets.Type.navigationBars());
                    getWindow().getInsetsController().setSystemBarsBehavior(
                            android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                }
            } else {
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                                | View.SYSTEM_UI_FLAG_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
            }
        } catch (Throwable ignored) {}
    }

    private void applyDark(WebSettings s) {
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                s.setAlgorithmicDarkeningAllowed(true);
            } else if (Build.VERSION.SDK_INT >= 29) {
                s.setForceDark(WebSettings.FORCE_DARK_ON);
            }
        } catch (Throwable ignored) {}
    }

    private boolean metaBool(String name, boolean def) {
        try {
            android.os.Bundle m = getPackageManager()
                    .getApplicationInfo(getPackageName(),
                            android.content.pm.PackageManager.GET_META_DATA).metaData;
            if (m != null && m.containsKey(name)) {
                Object v = m.get(name);
                if (v instanceof Boolean) return (Boolean) v;
                if (v instanceof String) return Boolean.parseBoolean((String) v);
                if (v instanceof Integer) return (Integer) v != 0;
            }
        } catch (Throwable ignored) {}
        return def;
    }

    /**
     * The page to open: the bundled copy, unless a converter repackages this
     * APK as a generic template and pins a per-build address:
     * &lt;meta-data android:name="com.affiliate.shopeevideo.URL"
     * android:value="https://example.com/app" /&gt;
     */
    private String appStartUrl() {
        try {
            android.content.pm.ApplicationInfo ai = getPackageManager()
                    .getApplicationInfo(getPackageName(),
                            android.content.pm.PackageManager.GET_META_DATA);
            if (ai.metaData != null) {
                String u = ai.metaData.getString("com.affiliate.shopeevideo.URL");
                if (u != null && (u.startsWith("https://") || u.startsWith("http://")
                        || u.startsWith("file:///"))) return u;
            }
        } catch (Throwable ignored) {}
        return "file:///android_asset/www/index.html";
    }

    /* ---------- downloads ---------- */

    /** Blob URLs cannot leave the WebView: fetch the blob in-page and hand it
        to the bridge as base64. */
    private void pullBlobToBridge(final String blobUrl) {
        if (web == null || blobUrl == null) return;
        String q = blobUrl.replace("\\", "\\\\").replace("'", "\\'");
        String js = "(function(){try{fetch('" + q + "').then(function(r){return r.blob();}).then(function(b){"
                    + "var fr=new FileReader();"
                    + "fr.onload=function(){try{"
                    + "var parts=String(fr.result).split(',');"
                    + "AndroidSave.saveBlobData(parts.length>1?parts[1]:'');}catch(e){}};"
                    + "fr.readAsDataURL(b);}).catch(function(){});}catch(e){}})();";
        try { web.evaluateJavascript(js, null); } catch (Throwable ignored) {}
    }

    private void enqueueHttpDownload(String url) {
        try {
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            if (dm == null) {
                toast("Download service unavailable");
                return;
            }
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            try { req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, Uri.parse(url).getLastPathSegment()); }
            catch (Throwable ignored) {}
            dm.enqueue(req);
            toast("Downloading…");
        } catch (Throwable t) {
            toast("Download failed");
        }
    }

    private class SaveBridge {
        @JavascriptInterface
        public void saveVideo(final String base64, final String filename) {
            saveBase64ToDownloads(base64, filename);
        }
        @JavascriptInterface
        public void saveBlobData(final String base64) {
            saveBase64ToDownloads(base64, "affiliate-video.webm");
        }
    }

    private void saveBase64ToDownloads(final String base64, final String filename) {
        final String name = (filename == null || filename.length() == 0) ? "affiliate-video.webm" : filename;
        new Thread(new Runnable() {
            @Override public void run() {
                final boolean ok = writeToDownloads(base64, name);
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        toast(ok ? ("Saved: " + name) : "Save failed");
                    }
                });
            }
        }).start();
    }

    private boolean writeToDownloads(String base64, String name) {
        if (base64 == null || base64.length() == 0) return false;
        byte[] data;
        try { data = Base64.decode(base64, Base64.DEFAULT); }
        catch (Throwable t) { return false; }
        if (Build.VERSION.SDK_INT >= 29) {
            ContentResolver cr = getContentResolver();
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
            cv.put(MediaStore.Downloads.MIME_TYPE, "video/webm");
            cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            Uri uri = null;
            OutputStream out = null;
            try {
                uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (uri == null) return false;
                out = cr.openOutputStream(uri);
                if (out == null) return false;
                out.write(data);
                out.flush();
                return true;
            } catch (Throwable t) {
                try { if (uri != null) cr.delete(uri, null, null); } catch (Throwable ignored) {}
                return false;
            } finally {
                try { if (out != null) out.close(); } catch (Throwable ignored) {}
            }
        } else {
            if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                pendingB64 = base64;
                pendingName = name;
                try { requestPermissions(new String[]{ android.Manifest.permission.WRITE_EXTERNAL_STORAGE }, REQ_STORAGE); }
                catch (Throwable ignored) {}
                return false;
            }
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            try {
                if (!dir.exists()) dir.mkdirs();
                FileOutputStream fos = new FileOutputStream(new File(dir, name));
                try {
                    fos.write(data);
                    fos.flush();
                } finally {
                    try { fos.close(); } catch (Throwable ignored) {}
                }
                return true;
            } catch (Throwable t) { return false; }
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_STORAGE && pendingB64 != null) {
            boolean granted = results != null && results.length > 0
                    && results[0] == PackageManager.PERMISSION_GRANTED;
            if (granted) {
                final String b = pendingB64, n = pendingName;
                pendingB64 = null; pendingName = null;
                saveBase64ToDownloads(b, n);
            } else {
                pendingB64 = null; pendingName = null;
                toast("Storage permission denied");
            }
        }
    }

    /* ---------- activity plumbing ---------- */

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && immersive) applyImmersive();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (immersive) applyImmersive();
        try { if (web != null) web.onResume(); } catch (Throwable ignored) {}
    }

    @Override
    protected void onPause() {
        try { hideCustomView(); } catch (Throwable ignored) {}
        try { if (web != null) web.onPause(); } catch (Throwable ignored) {}
        super.onPause();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (web != null) web.saveState(out);
    }

    @Override
    protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code == REQ_FILE && fileChooser != null) {
            ValueCallback<Uri[]> cb = fileChooser;
            fileChooser = null;
            try {
                cb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
            } catch (Throwable t) {
                try { cb.onReceiveValue(null); } catch (Throwable ignored) {}
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (web == null) {
            super.onBackPressed();
            return;
        }
        if (customView != null) {
            hideCustomView();
            return;
        }
        if (web.canGoBack()) {
            web.goBack();
            return;
        }
        long now = System.currentTimeMillis();
        if (now - lastBackPress < 2000) {
            if (backToast != null) backToast.cancel();
            super.onBackPressed();
        } else {
            lastBackPress = now;
            if (backToast != null) backToast.cancel();
            backToast = Toast.makeText(this, "Press back again to exit", Toast.LENGTH_SHORT);
            backToast.show();
        }
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }

    public void hideCustomView() {
        try {
            if (customView != null) {
                try {
                    FrameLayout decor = (FrameLayout) getWindow().getDecorView();
                    decor.removeView(customView);
                } catch (Throwable ignored) {}
                customView = null;
            }
            if (web != null) web.setVisibility(View.VISIBLE);
            try { if (customCb != null) customCb.onCustomViewHidden(); } catch (Throwable ignored) {}
            customCb = null;
        } catch (Throwable ignored) {}
    }

    private void toast(String msg) {
        try { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show(); }
        catch (Throwable ignored) {}
    }
}
