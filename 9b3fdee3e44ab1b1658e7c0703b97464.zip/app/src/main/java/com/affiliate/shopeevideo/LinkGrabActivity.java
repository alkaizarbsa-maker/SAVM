package com.affiliate.shopeevideo;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Window;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Transparent clipboard trampoline for the panel's "+ Link" button.
 *
 * WHY this exists: on Android 10+ a background Service can no longer read
 * the clipboard (only the focused app / IME can). QuickPanelService runs as
 * an overlay with FLAG_NOT_FOCUSABLE, so reading directly from the service
 * always comes back empty — "Copy a Shopee link first, then tap + Link"
 * even when the user DID copy. A translucent Activity DOES get window
 * focus for a split second, which satisfies the platform check, so the
 * panel now launches this activity instead of reading from the service.
 * It grabs the clipboard, appends one {kind:link} entry to the same
 * panel_inbox.json the service + MainActivity share, toasts, finishes
 * immediately and drops the user straight back to Shopee. Never opens Main.
 */
public class LinkGrabActivity extends Activity {

    private boolean done = false;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        try { requestWindowFeature(Window.FEATURE_NO_TITLE); } catch (Throwable ignored) {}
        // Wait for window focus (the clipboard gate on Android 10+), with a
        // timed fallback so very old devices still complete without focus.
        try {
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override public void run() { grabOnce(); }
            }, 700);
        } catch (Throwable ignored) {}
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) grabOnce();
    }

    private synchronized void grabOnce() {
        if (done) return;
        done = true;
        String clip = null;
        try {
            ClipboardManager cm =
                    (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null && cm.hasPrimaryClip()) {
                ClipData cd = cm.getPrimaryClip();
                if (cd != null && cd.getItemCount() > 0) {
                    CharSequence cs = cd.getItemAt(0).coerceToText(this);
                    if (cs != null) clip = cs.toString().trim();
                }
            }
        } catch (Throwable ignored) {}
        if (clip == null || clip.length() == 0) {
            toast("Copy a Shopee link first, then tap + Link");
            finishQuiet();
            return;
        }
        if (!(clip.startsWith("http://") || clip.startsWith("https://")
                || clip.contains("shopee") || clip.matches("(?s).{4,2048}"))) {
            toast("Clipboard has no link to save");
            finishQuiet();
            return;
        }
        // Cover-first rule + auto-merge: a link may never stand alone.
        // +Link refuses until at least one shot/cover/Full save sits in the
        // inbox, then attaches the URL straight onto the newest save that
        // has no link yet — so cover + link become ONE row with one
        // Add Product button, never two separate saves.
        try {
            synchronized (QuickPanelService.INBOX_LOCK) {
                File dir = getExternalFilesDir("panel");
                if (dir == null) dir = new File(getFilesDir(), "panel");
                File inbox = new File(dir, "panel_inbox.json");
                JSONArray arr = QuickPanelService.readInboxFile(inbox);
                if (arr == null) {
                    toast("Inbox busy — tap + Link again");
                    finishQuiet();
                    return;
                }
                JSONObject target = null;
                boolean anyCover = false;
                for (int i = arr.length() - 1; i >= 0; i--) {
                    try {
                        JSONObject e = arr.getJSONObject(i);
                        String k = e.optString("kind", "");
                        // Shots count as covers: the shot file IS the cropped
                        // product card, so a screenshot + link is complete.
                        boolean coverish = ("cover".equals(k) || "shot".equals(k)
                                || "full".equals(k))
                                && (e.has("file") || e.has("cover"));
                        if (!coverish) continue;
                        anyCover = true;
                        if (!e.has("link") || e.optString("link", "").length() == 0) {
                            target = e;
                            break;
                        }
                    } catch (Throwable ignored) {}
                }
                if (!anyCover) {
                    toast("Add a cover first — tap +Cover before +Link");
                    finishQuiet();
                    return;
                }
                String shortClip = clip.length() > 2048 ? clip.substring(0, 2048) : clip;
                if (target != null) {
                    target.put("link", shortClip);
                    if (!QuickPanelService.writeInboxAtomic(inbox, arr)) {
                        toast("Inbox busy — tap + Link again");
                        finishQuiet();
                        return;
                    }
                    try { QuickPanelService.noteInboxChanged(); } catch (Throwable ignored) {}
                    toast("Link attached to your cover — one save");
                } else {
                    JSONObject o = new JSONObject();
                    o.put("id", "l" + System.currentTimeMillis());
                    o.put("kind", "link");
                    o.put("link", shortClip);
                    o.put("time", new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",
                            Locale.US).format(new Date()));
                    arr.put(o);
                    while (arr.length() > 200) arr.remove(0);
                    if (!QuickPanelService.writeInboxAtomic(inbox, arr)) {
                        toast("Inbox busy — tap + Link again");
                        finishQuiet();
                        return;
                    }
                    try { QuickPanelService.noteInboxChanged(); } catch (Throwable ignored) {}
                    toast("Link saved — attach it with \u2192 product link");
                }
            }
        } catch (Throwable t) {
            toast("Could not save link");
        }
        finishQuiet();
    }

    private void finishQuiet() {
        try { finish(); } catch (Throwable ignored) {}
        try { moveTaskToBack(true); } catch (Throwable ignored) {}
    }

    private void toast(String msg) {
        try { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show(); }
        catch (Throwable ignored) {}
    }
}
