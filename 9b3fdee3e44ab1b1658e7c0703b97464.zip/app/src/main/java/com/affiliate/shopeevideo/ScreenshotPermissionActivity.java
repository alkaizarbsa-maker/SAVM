package com.affiliate.shopeevideo;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.view.Window;
import android.widget.Toast;

/**
 * Transparent trampoline for the one-time MediaProjection consent.
 *
 * Why this exists (the "stay where you are" fix): the old flow asked for
 * screen-capture permission from MainActivity, which yanked the user out of
 * Shopee into the Video Maker app and then screenshotted the *app* instead
 * of the Shopee product page. This activity is
 * Theme.Translucent.NoTitleBar + noHistory + excludeFromRecents, so it never
 * visually leaves the current app: the system capture dialog appears right
 * over Shopee, and this activity finishes immediately, dropping the user
 * straight back where they were. It never launches MainActivity.
 */
public class ScreenshotPermissionActivity extends Activity {

    public static final int REQ_CAPTURE = 2001;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        try {
            requestWindowFeature(Window.FEATURE_NO_TITLE);
        } catch (Throwable ignored) {}
        // Do not stay in recents / history: finish() returns straight to Shopee.
        try {
            MediaProjectionManager mgr =
                    (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            if (mgr == null) {
                toast("Screen capture unavailable on this device");
                finish();
                return;
            }
            startActivityForResult(mgr.createScreenCaptureIntent(), REQ_CAPTURE);
        } catch (Throwable t) {
            toast("Could not ask for capture permission");
            try { finish(); } catch (Throwable ignored) {}
        }
    }

    @Override
    protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        try {
            if (code != REQ_CAPTURE) { try { finish(); } catch (Throwable ignored) {} return; }
            if (result == RESULT_OK && data != null) {
                // NOTE: must pass resultCode (RESULT_OK), NOT the requestCode.
                // Passing the requestCode was the "tap again, nothing saved" bug:
                // getMediaProjection() rejects anything but RESULT_OK.
                QuickPanelService.setProjection(result, data);
                // Wake the pending capture (if the user tapped a panel button
                // that triggered this consent flow). Never opens MainActivity.
                QuickPanelService.capturePending();
            } else {
                toast("Capture cancelled — panel stays, nothing saved");
                QuickPanelService.clearPending();
            }
        } catch (Throwable ignored) {}
        try { finish(); } catch (Throwable ignored) {}
        // Extra safety: never linger in the task stack above Shopee.
        try { moveTaskToBack(true); } catch (Throwable ignored) {}
    }

    private void toast(String msg) {
        try { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show(); }
        catch (Throwable ignored) {}
    }
}
