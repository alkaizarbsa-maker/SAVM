package com.affiliate.shopeevideo;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Window;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Transparent file picker trampoline for the "+ Cover" panel button.
 *
 * Same "stay where you are" contract as the capture flow: this activity is
 * translucent + noHistory + excludeFromRecents, launches the system document
 * picker, copies the chosen image into the panel inbox, finishes immediately
 * and drops the user straight back to Shopee. It never launches MainActivity.
 */
public class PanelPickActivity extends Activity {

    public static final int REQ_PICK = 3001;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        try { requestWindowFeature(Window.FEATURE_NO_TITLE); } catch (Throwable ignored) {}
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(i, REQ_PICK);
        } catch (Throwable t) {
            toast("No file picker on this device");
            try { finish(); } catch (Throwable ignored) {}
        }
    }

    @Override
    protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        try {
            if (code != REQ_PICK) { try { finish(); } catch (Throwable ignored) {} return; }
            if (result == RESULT_OK && data != null && data.getData() != null) {
                Uri uri = data.getData();
                // Reject non-images up front (zips, videos, webm…): the old
                // code tried to decode them and died with a generic toast.
                String mime = null;
                try { mime = getContentResolver().getType(uri); } catch (Throwable ignored) {}
                if (mime != null && !mime.startsWith("image/")) {
                    toast("That isn't a photo — pick an image file");
                    try { finish(); } catch (Throwable ignored) {}
                    try { moveTaskToBack(true); } catch (Throwable ignored) {}
                    return;
                }
                try {
                    getContentResolver().takePersistableUriPermission(uri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Throwable ignored) {}
                lastError = null;
                String saved = copyIntoInbox(uri, mime);
                if (saved != null) {
                  toast("Cover saved — open the app, Refresh inbox, Add Product");
                  try { QuickPanelService.noteInboxChanged(); } catch (Throwable ignored) {}
                }
                else toast(lastError != null ? lastError : "Could not read that image");
            } else {
                toast("No cover picked — panel stays");
            }
        } catch (Throwable ignored) {}
        try { finish(); } catch (Throwable ignored) {}
        try { moveTaskToBack(true); } catch (Throwable ignored) {}
    }

    private String lastError = null;

    private String copyIntoInbox(Uri uri, String mime) {
        try {
            // Read the bytes first: some providers (Downloads, cloud photos)
            // hand out one-shot streams that decodeStream() alone chokes on,
            // and huge photos OOM if decoded at full size. Decode bounds
            // first, then downsample straight to max 800px. If the pixels
            // won't decode at all, fall back to saving the raw bytes — the
            // maker reads covers through an <img> tag, so any image format
            // works. A cover save should basically never fail now.
            byte[] raw = readAll(uri);
            if (raw == null || raw.length == 0) { lastError = "Empty file — pick another photo"; return null; }
            File dir = getExternalFilesDir("panel");
            if (dir == null) dir = new File(getFilesDir(), "panel");
            try { if (!dir.exists()) dir.mkdirs(); } catch (Throwable ignored) {}
            String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
                    .format(new Date());
            File out;
            android.graphics.BitmapFactory.Options bo =
                    new android.graphics.BitmapFactory.Options();
            bo.inJustDecodeBounds = true;
            try {
                android.graphics.BitmapFactory.decodeByteArray(raw, 0, raw.length, bo);
            } catch (Throwable ignored) {}
            android.graphics.Bitmap src = null;
            if (bo.outWidth > 0 && bo.outHeight > 0) {
                int sample = 1;
                while ((bo.outWidth / (sample * 2)) >= 800
                        || (bo.outHeight / (sample * 2)) >= 800) sample *= 2;
                android.graphics.BitmapFactory.Options bd =
                        new android.graphics.BitmapFactory.Options();
                bd.inSampleSize = sample;
                try {
                    src = android.graphics.BitmapFactory.decodeByteArray(raw, 0, raw.length, bd);
                } catch (Throwable ignored) { src = null; }
            }
            if (src != null) {
                int w = src.getWidth(), h = src.getHeight();
                double sc = Math.min(1.0, 800.0 / Math.max(w, h));
                android.graphics.Bitmap bmp = src;
                if (sc < 1.0) {
                    int nw = Math.max(1, (int) (w * sc));
                    int nh = Math.max(1, (int) (h * sc));
                    try {
                        bmp = android.graphics.Bitmap.createScaledBitmap(src, nw, nh, true);
                    } catch (Throwable t) { bmp = src; }
                }
                out = new File(dir, "cover_pick_" + stamp + ".jpg");
                FileOutputStream fos = new FileOutputStream(out);
                try {
                    bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 88, fos);
                    fos.flush();
                } finally { try { fos.close(); } catch (Throwable ignored) {} }
                try { if (bmp != src) bmp.recycle(); } catch (Throwable ignored) {}
                try { src.recycle(); } catch (Throwable ignored) {}
            } else {
                // Pixels won't decode (odd format) — keep the raw bytes.
                String ext = ".jpg";
                try {
                    if (mime != null && mime.startsWith("image/")) {
                        String sub = mime.substring(6).toLowerCase(java.util.Locale.US);
                        if (sub.contains("png")) ext = ".png";
                        else if (sub.contains("webp")) ext = ".webp";
                        else if (sub.contains("gif")) ext = ".gif";
                    }
                } catch (Throwable ignored) {}
                if (raw.length > (15 << 20)) { lastError = "Photo too big (15MB+) — pick a smaller one"; return null; }
                out = new File(dir, "cover_pick_" + stamp + ext);
                FileOutputStream fos2 = new FileOutputStream(out);
                try { fos2.write(raw); fos2.flush(); }
                finally { try { fos2.close(); } catch (Throwable ignored) {} }
            }
            raw = null;
            // Append to the same inbox JSON the service + MainActivity share.
            // Atomic + never-wipe: if the file is mid-write, wait and retry;
            // if it still can't be read, keep the old file and fail loudly
            // instead of overwriting 18 shots with 1 cover.
            boolean appended = false;
            try {
                synchronized (QuickPanelService.INBOX_LOCK) {
                    File inbox = new File(dir, "panel_inbox.json");
                    org.json.JSONArray arr = QuickPanelService.readInboxFile(inbox);
                    if (arr == null) { lastError = "Inbox busy — tap + Cover again"; return null; }
                    JSONObject o = new JSONObject();
                    o.put("id", "c" + System.currentTimeMillis());
                    o.put("kind", "cover");
                    o.put("file", out.getName());
                    o.put("time", new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",
                            Locale.US).format(new Date()));
                    arr.put(o);
                    while (arr.length() > 200) arr.remove(0);
                    appended = QuickPanelService.writeInboxAtomic(inbox, arr);
                    if (!appended) { lastError = "Inbox busy — tap + Cover again"; return null; }
                }
            } catch (Throwable t) { lastError = "Could not save cover"; return null; }
            // Also leave a copy where the Gallery can see it.
            try { copyToGallery(out, "cover"); } catch (Throwable ignored) {}
            return out.getName();
        } catch (Throwable t) { return null; }
    }

    /** Fully read a content URI (handles one-shot Download/cloud streams). */
    private byte[] readAll(Uri uri) {
        InputStream in = null;
        try {
            in = getContentResolver().openInputStream(uri);
            if (in == null) return null;
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) {
                bos.write(buf, 0, n);
                if (bos.size() > (20 << 20)) break; // 20MB sanity cap
            }
            bos.flush();
            return bos.toByteArray();
        } catch (Throwable t) { return null; }
        finally { try { if (in != null) in.close(); } catch (Throwable ignored) {} }
    }

    private void copyToGallery(File src, String kind) {
        try {
            String name = src.getName();
            String mime = "image/jpeg";
            try {
                String ln = name.toLowerCase(java.util.Locale.US);
                if (ln.endsWith(".png")) mime = "image/png";
                else if (ln.endsWith(".webp")) mime = "image/webp";
                else if (ln.endsWith(".gif")) mime = "image/gif";
            } catch (Throwable ignored) {}
            android.content.ContentValues cv = new android.content.ContentValues();
            cv.put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, name);
            cv.put(android.provider.MediaStore.Images.Media.MIME_TYPE, mime);
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                cv.put(android.provider.MediaStore.Images.Media.RELATIVE_PATH,
                        android.os.Environment.DIRECTORY_PICTURES + "/AffVideo");
                cv.put(android.provider.MediaStore.Images.Media.IS_PENDING, 1);
            }
            android.net.Uri uri = getContentResolver().insert(
                    android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
            if (uri == null) return;
            java.io.InputStream in = new java.io.FileInputStream(src);
            java.io.OutputStream out = getContentResolver().openOutputStream(uri);
            try {
                byte[] buf = new byte[8192]; int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                out.flush();
            } finally {
                try { in.close(); } catch (Throwable ignored) {}
                try { if (out != null) out.close(); } catch (Throwable ignored) {}
            }
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                cv = new android.content.ContentValues();
                cv.put(android.provider.MediaStore.Images.Media.IS_PENDING, 0);
                try { getContentResolver().update(uri, cv, null, null); }
                catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {}
    }

    private void toast(String msg) {
        try { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show(); }
        catch (Throwable ignored) {}
    }
}
