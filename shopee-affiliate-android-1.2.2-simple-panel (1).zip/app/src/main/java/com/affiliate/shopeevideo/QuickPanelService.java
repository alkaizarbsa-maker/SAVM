package com.affiliate.shopeevideo;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Edge quick panel: a floating overlay that works *over* other apps (Shopee,
 * browser, gallery…) so the user never leaves where they are.
 *
 * Layout mirrors the user's screenshot:
 *   "Video maker" title
 *   [camera] [Full] [–]      <- row 1: shot, full-save, minimise
 *   [+ Cover] [+ Link]        <- row 2: cover crop, link grab
 *   footer: "nothing saved yet — no app needed" / "N saved • …"
 *
 * CRITICAL FIX vs the old behaviour: none of the four buttons ever calls
 * startActivity(MainActivity). Every action runs inside this Service
 * (WindowManager overlay + MediaProjection + files + clipboard) and ends
 * with a Toast while Shopee stays in the foreground. The *only* activities
 * ever launched are:
 *   1. the transparent ScreenshotPermissionActivity (system capture dialog,
 *      finishes immediately, returns to Shopee), and
 *   2. the one-time system overlay-permission Settings screen (setup only).
 *
 * Capture model:
 *   camera  = full-screen PNG screenshot now.
 *   Full    = one-tap full save: full PNG + center-square cover JPG +
 *             clipboard URL (if any) in a single inbox entry group.
 *   +Cover  = center-square JPG cover crop of the live screen now.
 *   +Link   = grab clipboard text (Shopee URL) into the inbox, no capture.
 *   –       = collapse to the edge bubble. Bubble tap re-expands.
 *             Long-press/drag moves the bubble; nothing opens the app.
 *
 * Inbox: getExternalFilesDir("panel")/panel_inbox.json  (JSONArray).
 * MainActivity reads it through the AndroidOverlay JS bridge and imports
 * covers/links into the maker without the user ever re-typing anything.
 */
public class QuickPanelService extends Service {

    public static final String ACTION_START = "com.affiliate.shopeevideo.PANEL_START";
    public static final String ACTION_STOP = "com.affiliate.shopeevideo.PANEL_STOP";

    private static final String CH_ID = "quick_panel";
    private static final int NOTIF_ID = 1701;

    // MediaProjection consent, held process-wide so later taps need no UI.
    private static int sResultCode = 0;
    private static Intent sResultData = null;
    private static MediaProjection sProjection = null;
    // A capture requested before consent arrived ("tap camera -> allow -> shot").
    private static volatile String sPendingKind = null; // "shot" | "cover" | "full"
    private static QuickPanelService sInstance = null;

    /** Called by ScreenshotPermissionActivity after the user allows capture. */
    public static void setProjection(int code, Intent data) {
        sResultCode = code;
        sResultData = data != null ? new Intent(data) : null;
        // Drop any previous projection so the new consent token is used.
        try { if (sProjection != null) sProjection.stop(); } catch (Throwable ignored) {}
        sProjection = null;
    }

    public static void clearPending() { sPendingKind = null; }

    /** Run whatever capture was waiting for consent, on the service thread. */
    public static void capturePending() {
        final QuickPanelService svc = sInstance;
        final String kind = sPendingKind;
        sPendingKind = null;
        if (svc == null || kind == null) return;
        svc.bgHandler.post(new Runnable() {
            @Override public void run() { svc.doCapture(kind); }
        });
    }

    public static boolean isRunning() { return sInstance != null; }

    private WindowManager wm;
    private View bubble;
    private LinearLayout panel;
    private TextView footerTv;
    private Handler mainHandler;
    private HandlerThread bgThread;
    private android.os.Handler bgHandler;
    private boolean expanded = false;
    private int captureSeq = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        sInstance = this;
        mainHandler = new Handler(Looper.getMainLooper());
        bgThread = new HandlerThread("panel-cap");
        try { bgThread.start(); } catch (Throwable ignored) {}
        try { bgHandler = new Handler(bgThread.getLooper()); } catch (Throwable t) {
            bgHandler = new Handler(Looper.getMainLooper());
        }
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        startFg();
        buildViews();
        showBubble();
        refreshFooter();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            if (intent != null && ACTION_STOP.equals(intent.getAction())) {
                stopSelf();
                return START_NOT_STICKY;
            }
        } catch (Throwable ignored) {}
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        try { if (bubble != null && bubble.getParent() != null) wm.removeView(bubble); } catch (Throwable ignored) {}
        try { if (panel != null && panel.getParent() != null) wm.removeView(panel); } catch (Throwable ignored) {}
        bubble = null; panel = null;
        try { if (sProjection != null) sProjection.stop(); } catch (Throwable ignored) {}
        sProjection = null;
        try { bgThread.quitSafely(); } catch (Throwable ignored) {}
        sInstance = null;
        try { stopForeground(true); } catch (Throwable ignored) {}
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    // ---------- foreground ----------

    private void startFg() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 26 && nm != null) {
                try {
                    NotificationChannel ch = new NotificationChannel(
                            CH_ID, "Quick panel", NotificationManager.IMPORTANCE_MIN);
                    ch.setShowBadge(false);
                    nm.createNotificationChannel(ch);
                } catch (Throwable ignored) {}
            }
            Intent app = new Intent(this, MainActivity.class);
            app.setAction("open-panel-settings");
            int mut = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;
            PendingIntent pi = PendingIntent.getActivity(this, 91, app,
                    PendingIntent.FLAG_UPDATE_CURRENT | mut);
            Notification.Builder b = Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(this, CH_ID) : new Notification.Builder(this);
            b.setContentTitle("Video-maker panel running")
             .setContentText("Use the floating panel over Shopee — buttons never leave the app")
             .setSmallIcon(android.R.drawable.ic_menu_camera)
             .setContentIntent(pi)
             .setOngoing(true);
            Notification n = b.build();
            try {
                if (Build.VERSION.SDK_INT >= 29) {
                    startForeground(NOTIF_ID, n,
                            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
                } else {
                    startForeground(NOTIF_ID, n);
                }
            } catch (Throwable t) {
                // Fallback for devices that reject the typed call at runtime.
                try { startForeground(NOTIF_ID, n); } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {}
    }

    // ---------- views (built in code, no XML needed) ----------

    private int dp(int v) {
        try {
            DisplayMetrics dm = getResources().getDisplayMetrics();
            return Math.round(v * dm.density);
        } catch (Throwable t) { return v * 3; }
    }

    private GradientDrawable cardBg() {
        GradientDrawable d = new GradientDrawable();
        d.setColor(0xF21B1B22);
        d.setCornerRadius(dp(22));
        d.setStroke(dp(1), 0xFF2A2A35);
        return d;
    }

    private void buildViews() {
        buildBubble();
        buildPanel();
    }

    private void buildBubble() {
        final TextView tv = new TextView(this);
        tv.setText("\uD83D\uDCF7"); // camera emoji, matches the panel icon
        tv.setTextSize(26);
        tv.setGravity(Gravity.CENTER);
        tv.setTextColor(Color.WHITE);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFFEE4D2D); // solid orange: visible on dark AND white apps
        bg.setCornerRadius(dp(32));
        bg.setStroke(dp(2), 0xFFFFFFFF);
        if (Build.VERSION.SDK_INT >= 16) tv.setBackground(bg);
        try { tv.setElevation(dp(8)); } catch (Throwable ignored) {}
        int s = dp(64);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(s, s);
        tv.setLayoutParams(lp);
        tv.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy; int downX, downY; boolean dragging; long downT;
            @Override public boolean onTouch(View v, MotionEvent e) {
                try {
                    WindowManager.LayoutParams p =
                            (WindowManager.LayoutParams) v.getLayoutParams();
                    switch (e.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            dx = p.x - e.getRawX(); dy = p.y - e.getRawY();
                            downX = p.x; downY = p.y; dragging = false;
                            downT = System.currentTimeMillis();
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            int nx = (int) (e.getRawX() + dx);
                            int ny = (int) (e.getRawY() + dy);
                            if (Math.abs(nx - downX) + Math.abs(ny - downY) > dp(8)) dragging = true;
                            if (dragging) {
                                p.x = nx; p.y = ny;
                                try { wm.updateViewLayout(v, p); } catch (Throwable ignored) {}
                            }
                            return true;
                        case MotionEvent.ACTION_UP:
                            if (!dragging && System.currentTimeMillis() - downT < 600) {
                                v.performClick();
                                showPanel();
                            }
                            return true;
                    }
                } catch (Throwable ignored) {}
                return false;
            }
        });
        bubble = tv;
    }

    private Button mkBtn(String label, int flex) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(Color.WHITE);
        GradientDrawable d = new GradientDrawable();
        d.setColor(0xFF2A2A35);
        d.setCornerRadius(dp(10));
        if (Build.VERSION.SDK_INT >= 16) b.setBackground(d);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                0, dp(46), flex <= 0 ? 1 : flex);
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));
        b.setLayoutParams(lp);
        try { b.setStateListAnimator(null); } catch (Throwable ignored) {}
        return b;
    }

    private void buildPanel() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        if (Build.VERSION.SDK_INT >= 16) root.setBackground(cardBg());
        int pad = dp(12);
        root.setPadding(pad, dp(10), pad, dp(8));

        TextView title = new TextView(this);
        title.setText("Video maker");
        title.setGravity(Gravity.CENTER);
        title.setTextColor(Color.WHITE);
        title.setTypeface(Typeface.create(Typeface.SERIF, Typeface.ITALIC));
        title.setTextSize(17);
        root.addView(title);

        // Row 1: shot | Full | minimise
        LinearLayout r1 = new LinearLayout(this);
        r1.setOrientation(LinearLayout.HORIZONTAL);
        final Button shotBtn = mkBtn("\uD83D\uDCF7", 1); // camera glyph
        shotBtn.setTextSize(20);
        shotBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                buzz(v);
                requestCapture("shot"); // stays over Shopee; never opens the app
            }
        });
        final Button fullBtn = mkBtn("Full", 2);
        fullBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                buzz(v);
                requestCapture("full"); // shot + cover + link in one tap
            }
        });
        final Button minBtn = mkBtn("\u2013", 1); // en-dash minimise
        minBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                buzz(v);
                showBubble(); // collapse to edge; current app keeps focus
            }
        });
        r1.addView(shotBtn); r1.addView(fullBtn); r1.addView(minBtn);
        root.addView(r1);

        // Row 2: + Cover | + Link
        LinearLayout r2 = new LinearLayout(this);
        r2.setOrientation(LinearLayout.HORIZONTAL);
        final Button coverBtn = mkBtn("+ Cover", 1);
        coverBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                buzz(v);
                openCoverPicker(); // system files, transparent, returns to Shopee
            }
        });
        final Button linkBtn = mkBtn("+ Link", 1);
        linkBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                buzz(v);
                saveClipboardLink(); // no capture, no app switch
            }
        });
        r2.addView(coverBtn); r2.addView(linkBtn);
        root.addView(r2);

        footerTv = new TextView(this);
        footerTv.setGravity(Gravity.CENTER);
        footerTv.setTextColor(0xFFA7A3B8);
        footerTv.setTextSize(11);
        footerTv.setTypeface(Typeface.create(Typeface.SERIF, Typeface.ITALIC));
        footerTv.setPadding(0, dp(6), 0, dp(2));
        root.addView(footerTv);

        // Drag the whole card by its title bar; touches outside still go to Shopee.
        title.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy;
            @Override public boolean onTouch(View v, MotionEvent e) {
                try {
                    WindowManager.LayoutParams p =
                            (WindowManager.LayoutParams) root.getLayoutParams();
                    switch (e.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            dx = p.x - e.getRawX(); dy = p.y - e.getRawY();
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            p.x = (int) (e.getRawX() + dx);
                            p.y = (int) (e.getRawY() + dy);
                            wm.updateViewLayout(root, p);
                            return true;
                    }
                } catch (Throwable ignored) {}
                return false;
            }
        });

        panel = root;
    }

    private WindowManager.LayoutParams overlayParams(int w, int h, int x, int y) {
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                w, h,
                Build.VERSION.SDK_INT >= 26
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        p.x = x; p.y = y;
        return p;
    }

    private void showBubble() {
        try {
            if (panel != null && panel.getParent() != null) wm.removeView(panel);
        } catch (Throwable ignored) {}
        // Drop the cached bubble too and re-add: guarantees it is attached,
        // visible and on top (an old GONE view could otherwise stay hidden).
        try {
            if (bubble != null && bubble.getParent() != null) {
                try { wm.removeView(bubble); } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {}
        expanded = false;
        try {
            bubble = null;
            buildBubble();
            Point sz = screenSize();
            wm.addView(bubble, overlayParams(dp(64), dp(64),
                    Math.max(0, sz.x - dp(80)), Math.max(200, sz.y / 3)));
            toast("Minimised — tap the orange 📷 bubble to reopen");
        } catch (Throwable t) {
            toast("Bubble failed: overlay permission?");
        }
    }

    private void showPanel() {
        try {
            if (bubble != null && bubble.getParent() != null) wm.removeView(bubble);
        } catch (Throwable ignored) {}
        expanded = true;
        try {
            if (panel.getParent() == null) {
                Point sz = screenSize();
                int w = Math.min(dp(300), sz.x - dp(24));
                wm.addView(panel, overlayParams(w,
                        WindowManager.LayoutParams.WRAP_CONTENT,
                        Math.max(dp(12), sz.x - w - dp(12)), Math.max(160, sz.y / 5)));
            } else {
                try { panel.setVisibility(View.VISIBLE); } catch (Throwable ignored) {}
            }
            refreshFooter();
        } catch (Throwable t) {
            toast("Panel failed: overlay permission?");
            showBubble();
        }
    }

    private Point screenSize() {
        Point out = new Point(1080, 1920);
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Rect b = wm.getCurrentWindowMetrics().getBounds();
                out.set(b.width(), b.height());
            } else {
                Display d = wm.getDefaultDisplay();
                try { d.getRealSize(out); }
                catch (Throwable t) { d.getSize(out); }
            }
        } catch (Throwable ignored) {}
        return out;
    }

    private void buzz(View v) {
        try { v.performHapticFeedback(
                android.view.HapticFeedbackConstants.VIRTUAL_KEY); } catch (Throwable ignored) {}
    }

    // ---------- inbox ----------

    private File panelDir() {
        File d = null;
        try { d = getExternalFilesDir("panel"); } catch (Throwable ignored) {}
        if (d == null) d = new File(getFilesDir(), "panel");
        try { if (!d.exists()) d.mkdirs(); } catch (Throwable ignored) {}
        return d;
    }

    private File inboxFile() { return new File(panelDir(), "panel_inbox.json"); }

    private synchronized JSONArray readInbox() {
        try {
            File f = inboxFile();
            if (!f.exists()) return new JSONArray();
            FileInputStream fis = new FileInputStream(f);
            try {
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                byte[] buf = new byte[8192]; int n;
                while ((n = fis.read(buf)) > 0) bos.write(buf, 0, n);
                String s = new String(bos.toByteArray(), "UTF-8").trim();
                if (s.length() == 0) return new JSONArray();
                return new JSONArray(s);
            } finally { try { fis.close(); } catch (Throwable ignored) {} }
        } catch (Throwable t) { return new JSONArray(); }
    }

    private synchronized void writeInbox(JSONArray arr) {
        try {
            FileOutputStream fos = new FileOutputStream(inboxFile());
            try { fos.write(arr.toString().getBytes("UTF-8")); fos.flush(); }
            finally { try { fos.close(); } catch (Throwable ignored) {} }
        } catch (Throwable ignored) {}
    }

    private synchronized void addEntry(JSONObject o) {
        try {
            JSONArray a = readInbox();
            a.put(o);
            // Cap at 200 entries so the file can never bloat the app.
            while (a.length() > 200) a.remove(0);
            writeInbox(a);
        } catch (Throwable ignored) {}
    }

    private void refreshFooter() {
        try {
            final JSONArray a = readInbox();
            final String txt;
            if (a.length() == 0) txt = "nothing saved yet \u2014 no app needed";
            else {
                int shots = 0, covers = 0, links = 0;
                for (int i = 0; i < a.length(); i++) {
                    try {
                        String k = a.getJSONObject(i).optString("kind", "");
                        if ("shot".equals(k)) shots++;
                        else if ("cover".equals(k)) covers++;
                        else if ("link".equals(k)) links++;
                        else if ("full".equals(k)) { shots++; covers++; }
                    } catch (Throwable ignored) {}
                }
                txt = a.length() + " saved \u2022 " + shots + " shot \u2022 "
                        + covers + " cover \u2022 " + links + " link";
            }
            mainHandler.post(new Runnable() {
                @Override public void run() {
                    try { if (footerTv != null) footerTv.setText(txt); }
                    catch (Throwable ignored) {}
                }
            });
        } catch (Throwable ignored) {}
    }

    // ---------- clipboard link (no capture, no app switch) ----------

    private void saveClipboardLink() {
        bgHandler.post(new Runnable() {
            @Override public void run() {
                String clip = null;
                try {
                    ClipboardManager cm =
                            (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null && cm.hasPrimaryClip()) {
                        ClipData cd = cm.getPrimaryClip();
                        if (cd != null && cd.getItemCount() > 0) {
                            CharSequence cs = cd.getItemAt(0).coerceToText(QuickPanelService.this);
                            if (cs != null) clip = cs.toString().trim();
                        }
                    }
                } catch (Throwable ignored) {}
                if (clip == null || clip.length() == 0) {
                    toast("Copy a Shopee link first, then tap + Link");
                    return;
                }
                // Accept bare product IDs too, but prefer real URLs.
                if (!(clip.startsWith("http://") || clip.startsWith("https://")
                        || clip.contains("shopee") || clip.matches("(?s).{4,2048}"))) {
                    toast("Clipboard has no link to save");
                    return;
                }
                try {
                    JSONObject o = new JSONObject();
                    o.put("id", "l" + System.currentTimeMillis());
                    o.put("kind", "link");
                    o.put("link", clip.length() > 2048 ? clip.substring(0, 2048) : clip);
                    o.put("time", isoNow());
                    addEntry(o);
                    refreshFooter();
                    toast("Link saved \u2014 stay here, keep shopping");
                } catch (Throwable t) {
                    toast("Could not save link");
                }
            }
        });
    }

    // ---------- capture ----------

    /** Entry from any of the 3 capture buttons. Never leaves the current app. */
    private void requestCapture(String kind) {
        if (!Settings.canDrawOverlays(this)) {
            toast("Overlay permission first (one-time setup in the app)");
            return;
        }
        if (sResultData == null) {
            // Ask the system for capture consent via the transparent activity:
            // Shopee stays visible underneath; no MainActivity is ever opened.
            sPendingKind = kind;
            try {
                Intent i = new Intent(this, ScreenshotPermissionActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                        | Intent.FLAG_ACTIVITY_NO_ANIMATION
                        | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
                startActivity(i);
                toast("Allow capture once \u2014 then stay here, tap again");
            } catch (Throwable t) {
                sPendingKind = null;
                toast("Could not start capture");
            }
            return;
        }
        final String k = kind;
        try {
            bgHandler.post(new Runnable() {
                @Override public void run() { doCapture(k); }
            });
        } catch (Throwable t) { toast("Capture busy — try again"); }
    }

    /** "+ Cover" opens system files via a transparent trampoline. */
    private void openCoverPicker() {
        try {
            Intent i = new Intent(this, PanelPickActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_NO_ANIMATION
                    | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
            startActivity(i);
            // The picker itself will toast once the cover is saved.
        } catch (Throwable t) {
            toast("Could not open files");
        }
    }

    private MediaProjection projection() {
        try {
            if (sProjection == null && sResultData != null) {
                MediaProjectionManager mgr =
                        (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
                if (mgr != null) sProjection = mgr.getMediaProjection(sResultCode, sResultData);
                // Android 14+ throws "Must register a callback before starting
                // capture" if we create a VirtualDisplay without this.
                if (sProjection != null) {
                    try {
                        android.os.Handler h = null;
                        try { h = mainHandler; } catch (Throwable ignored) {}
                        if (h == null) h = new android.os.Handler(
                                android.os.Looper.getMainLooper());
                        final android.os.Handler hh = h;
                        sProjection.registerCallback(new MediaProjection.Callback() {
                            @Override public void onStop() {
                                try { sProjection = null; } catch (Throwable ignored) {}
                                try { sResultData = null; } catch (Throwable ignored) {}
                                try {
                                    hh.post(new Runnable() {
                                        @Override public void run() {
                                            toast("Capture session ended — tap again to allow");
                                            refreshFooter();
                                        }
                                    });
                                } catch (Throwable ignored) {}
                            }
                        }, h);
                    } catch (Throwable ignored) {}
                }
            }
        } catch (Throwable t) {
            try {
                String msg = String.valueOf(t.getMessage());
                if (msg != null && msg.length() > 120) msg = msg.substring(0, 120);
                toast("Capture failed: " + msg);
            } catch (Throwable ignored) {}
            sProjection = null;
            sResultData = null; // consent died (reboot/revoke): ask again next tap.
        }
        return sProjection;
    }

    private void doCapture(final String kind) {
        MediaProjection mp = projection();
        if (mp == null) {
            mainHandler.post(new Runnable() {
                @Override public void run() { requestCapture(kind); }
            });
            return;
        }
        // Hide our own floating window so it is NOT in the shot.
        // MediaProjection captures everything on screen, including overlays.
        final boolean wasExpanded = expanded;
        try {
            mainHandler.post(new Runnable() {
                @Override public void run() {
                    try {
                        if (bubble != null) bubble.setVisibility(View.GONE);
                        if (panel != null) panel.setVisibility(View.GONE);
                    } catch (Throwable ignored) {}
                }
            });
        } catch (Throwable ignored) {}
        try { Thread.sleep(300); } catch (InterruptedException ignored) {}
        Point sz = screenSize();
        int W = sz.x, H = sz.y;
        if (W <= 0 || H <= 0) { toast("Bad display size"); restoreOverlay(wasExpanded); return; }
        // Full native resolution (up to 2560px on the long side) so covers stay
        // sharp for the video maker. The old 1080p cap is what made crops soft.
        double down = Math.min(1.0, 2560.0 / Math.max(W, H));
        final int cw = Math.max(2, (int) (W * down));
        final int ch = Math.max(2, (int) (H * down));
        int dpi = 320;
        try { dpi = getResources().getDisplayMetrics().densityDpi; } catch (Throwable ignored) {}

        ImageReader reader = null;
        VirtualDisplay vd = null;
        Bitmap bmp = null;
        try {
            reader = ImageReader.newInstance(cw, ch, PixelFormat.RGBA_8888, 2);
            vd = mp.createVirtualDisplay("panel-cap", cw, ch, dpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    reader.getSurface(), null, null);
            try { Thread.sleep(380); } catch (InterruptedException ignored) {}
            Image img = null;
            try { img = reader.acquireLatestImage(); } catch (Throwable ignored) {}
            if (img == null) {
                try { Thread.sleep(300); } catch (InterruptedException ignored) {}
                try { img = reader.acquireLatestImage(); } catch (Throwable ignored) {}
            }
            if (img == null) { toast("Shot came back empty — try again"); restoreOverlay(wasExpanded); return; }
            try {
                Image.Plane[] planes = img.getPlanes();
                ByteBuffer buf = planes[0].getBuffer();
                int rowStride = planes[0].getRowStride();
                int pixStride = planes[0].getPixelStride();
                int rowPad = rowStride - pixStride * cw;
                Bitmap full = Bitmap.createBitmap(
                        cw + rowPad / Math.max(1, pixStride), ch, Bitmap.Config.ARGB_8888);
                full.copyPixelsFromBuffer(buf);
                bmp = Bitmap.createBitmap(full, 0, 0, cw, ch);
                try { full.recycle(); } catch (Throwable ignored) {}
            } finally { try { img.close(); } catch (Throwable ignored) {} }
        } catch (Throwable t) {
            toast("Capture failed: " + t.getMessage());
            restoreOverlay(wasExpanded);
            return;
        } finally {
            try { if (vd != null) vd.release(); } catch (Throwable ignored) {}
            try { if (reader != null) reader.close(); } catch (Throwable ignored) {}
        }
        if (bmp == null) { toast("Shot came back empty — try again"); restoreOverlay(wasExpanded); return; }

        try {
            String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
                    .format(new Date()) + "_" + (++captureSeq);
            if ("shot".equals(kind)) {
                // Clean product only, squared to the template's centre frame so
                // nothing gets cut there. Panel was hidden during capture.
                Bitmap rect = smartCropProduct(bmp);
                Bitmap crop = squareFit(rect);
                try { if (rect != bmp && rect != crop) rect.recycle(); } catch (Throwable ignored) {}
                File f = new File(panelDir(), "shot_" + stamp + ".png");
                savePng(crop, f);
                try { copyImageToGallery(f, "image/png"); } catch (Throwable ignored) {}
                try { if (crop != bmp) crop.recycle(); } catch (Throwable ignored) {}
                JSONObject o = new JSONObject();
                o.put("id", "s" + System.currentTimeMillis());
                o.put("kind", "shot");
                o.put("file", f.getName());
                o.put("time", isoNow());
                addEntry(o);
                refreshFooter();
                toast("Product saved (fits template) to Gallery + inbox — still here");
            } else if ("cover".equals(kind)) {
                Bitmap rect = smartCropProduct(bmp);
                Bitmap crop = squareFit(rect);
                try { if (rect != bmp && rect != crop) rect.recycle(); } catch (Throwable ignored) {}
                File f = new File(panelDir(), "cover_" + stamp + ".jpg");
                saveJpg(crop, f, 88);
                try { if (crop != bmp) crop.recycle(); } catch (Throwable ignored) {}
                try { copyImageToGallery(f, "image/jpeg"); } catch (Throwable ignored) {}
                JSONObject o = new JSONObject();
                o.put("id", "c" + System.currentTimeMillis());
                o.put("kind", "cover");
                o.put("file", f.getName());
                o.put("time", isoNow());
                addEntry(o);
                refreshFooter();
                toast("Cover saved (cropped) to Gallery + inbox — still here");
            } else { // "full": full screenshot (context) + clean cover + link
                File fs = new File(panelDir(), "shot_full_" + stamp + ".png");
                savePng(bmp, fs);
                try { copyImageToGallery(fs, "image/png"); } catch (Throwable ignored) {}
                Bitmap rect = smartCropProduct(bmp);
                Bitmap crop = squareFit(rect);
                try { if (rect != bmp && rect != crop) rect.recycle(); } catch (Throwable ignored) {}
                File fc = new File(panelDir(), "cover_" + stamp + ".jpg");
                saveJpg(crop, fc, 88);
                try { if (crop != bmp) crop.recycle(); } catch (Throwable ignored) {}
                try { copyImageToGallery(fc, "image/jpeg"); } catch (Throwable ignored) {}
                String clip = readClip();
                JSONObject o = new JSONObject();
                o.put("id", "f" + System.currentTimeMillis());
                o.put("kind", "full");
                o.put("file", fs.getName());
                o.put("cover", fc.getName());
                if (clip != null) o.put("link", clip);
                o.put("time", isoNow());
                addEntry(o);
                refreshFooter();
                toast(clip != null
                        ? "Full saved: Gallery + inbox (full+cover+link) — still here"
                        : "Full saved: Gallery + inbox (full+cover) — copy a link first for +link");
            }
        } catch (Throwable t) {
            toast("Save failed");
        } finally {
            try { bmp.recycle(); } catch (Throwable ignored) {}
            restoreOverlay(wasExpanded);
        }
    }

    private void restoreOverlay(final boolean wasExpanded) {
        try {
            mainHandler.post(new Runnable() {
                @Override public void run() {
                    try {
                        if (wasExpanded) {
                            if (bubble != null) bubble.setVisibility(View.GONE);
                            if (panel != null) panel.setVisibility(View.VISIBLE);
                        } else {
                            if (panel != null) panel.setVisibility(View.GONE);
                            if (bubble != null) bubble.setVisibility(View.VISIBLE);
                        }
                    } catch (Throwable ignored) {}
                }
            });
        } catch (Throwable ignored) {}
    }

    /**
     * Smart product crop: finds the colourful product card in the middle and
     * drops the status bar, shop chrome, price/BuyNow card, share row and dark
     * side bars. Falls back to a safe centre band (3%/14%/97%/72%) when the
     * detection is unsure. Always returns a new Bitmap (or the source).
     */
    private Bitmap smartCropProduct(Bitmap src) {
        try {
            int W = src.getWidth(), H = src.getHeight();
            // Analyse a tiny copy for speed.
            int tw = 72, th = Math.max(72, Math.min(160, (int) (72f * H / Math.max(1, W))));
            Bitmap small = null;
            try {
                small = Bitmap.createScaledBitmap(src, tw, th, true);
            } catch (Throwable t) { return centerSquare(src); }
            int[] px = new int[tw * th];
            try { small.getPixels(px, 0, tw, 0, 0, tw, th); }
            catch (Throwable t) {
                try { small.recycle(); } catch (Throwable ignored) {}
                return centerSquare(src);
            }
            // Product = saturated colour. White price cards / BuyNow red button
            // live BELOW the search band, so the search stops above them.
            // (Old code also counted grey texture, which is why the white
            // price card + red Buy Now leaked into the crop.)
            float[] rowScore = new float[th];
            float[] rowBright = new float[th];
            for (int y = 0; y < th; y++) {
                int hit = 0, bright = 0;
                for (int x = 0; x < tw; x++) {
                    int c = px[y * tw + x];
                    int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
                    int mx = Math.max(r, Math.max(g, b));
                    int mn = Math.min(r, Math.min(g, b));
                    float sat = mx == 0 ? 0 : (mx - mn) / (float) mx;
                    if (mx > 40) bright++;
                    // saturated product art only — no grey-texture fallback
                    if (sat > 0.25 && mx > 40 && mx < 250) hit++;
                }
                rowScore[y] = hit / (float) tw;
                rowBright[y] = bright / (float) tw;
            }
            // Search band: skip top system/app bar, stop ABOVE bottom shop UI
            // (price card + Buy Now + share live below ~74%).
            int y0 = (int) (th * 0.08), y1 = (int) (th * 0.74);
            int top = -1, bottom = -1;
            for (int y = y0; y < y1; y++) {
                if (top < 0 && rowScore[y] > 0.30) top = y;
            }
            for (int y = y1 - 1; y >= y0; y--) {
                if (bottom < 0 && rowScore[y] > 0.30) { bottom = y; break; }
            }
            // Column bounds inside the band: drop black side bars (gallery
            // letterbox) and keep the card. Score columns by brightness.
            int lCol = 0, rCol = tw - 1;
            if (top >= 0 && bottom > top) {
                float[] colScore = new float[tw];
                for (int x = 0; x < tw; x++) {
                    int hit = 0, n = 0;
                    for (int y = top; y <= bottom; y += 2) {
                        int c = px[y * tw + x];
                        int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
                        int mx = Math.max(r, Math.max(g, b));
                        if (mx > 25) hit++;
                        n++;
                    }
                    colScore[x] = n == 0 ? 0 : hit / (float) n;
                }
                for (int x = 0; x < tw; x++) {
                    if (colScore[x] > 0.5) { lCol = x; break; }
                }
                for (int x = tw - 1; x >= 0; x--) {
                    if (colScore[x] > 0.5) { rCol = x; break; }
                }
            }
            try { small.recycle(); } catch (Throwable ignored) {}
            int l, t, r, b;
            if (top >= 0 && bottom > top + th * 0.15) {
                l = (int) ((lCol / (float) tw) * W);
                r = (int) (((rCol + 1) / (float) tw) * W);
                t = (int) ((top / (float) th) * H);
                b = (int) (((bottom + 1) / (float) th) * H);
                // Pad slightly inside the detected edges (they sit on the border).
                int padX = (int) ((r - l) * 0.01);
                int padY = (int) ((b - t) * 0.015);
                l += padX; r -= padX; t += padY; b -= padY;
            } else {
                // Fallback band tuned to the Shopee layout in the user's photo:
                // below search/cart row, above price/BuyNow card.
                l = (int) (W * 0.03);
                t = (int) (H * 0.14);
                r = (int) (W * 0.97);
                b = (int) (H * 0.70);
            }
            if (l < 0) l = 0; if (t < 0) t = 0;
            if (r > W) r = W; if (b > H) b = H;
            if (r - l < W * 0.3 || b - t < H * 0.15 || r <= l || b <= t) {
                return centerSquare(src);
            }
            try {
                return Bitmap.createBitmap(src, l, t, r - l, b - t);
            } catch (Throwable tt) { return centerSquare(src); }
        } catch (Throwable t) { return centerSquare(src); }
    }

    private String readClip() {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null && cm.hasPrimaryClip()) {
                ClipData cd = cm.getPrimaryClip();
                if (cd != null && cd.getItemCount() > 0) {
                    CharSequence cs = cd.getItemAt(0).coerceToText(this);
                    if (cs != null) {
                        String s = cs.toString().trim();
                        if (s.startsWith("http://") || s.startsWith("https://")
                                || s.contains("shopee"))
                            return s.length() > 2048 ? s.substring(0, 2048) : s;
                    }
                }
            }
        } catch (Throwable ignored) {}
        return null;
    }

    private Bitmap centerSquare(Bitmap src) {
        try {
            int w = src.getWidth(), h = src.getHeight();
            // Shopee product photos sit centre-frame: 86% square keeps the
            // product while dropping status/nav bars and shop chrome.
            int side = (int) (Math.min(w, h) * 0.86);
            if (side < 8) side = Math.min(w, h);
            int x = (w - side) / 2, y = (h - side) / 2;
            if (x < 0) x = 0; if (y < 0) y = 0;
            if (x + side > w) side = w - x;
            if (y + side > h) side = h - y;
            return Bitmap.createBitmap(src, x, y, side, side);
        } catch (Throwable t) { return src; }
    }

    /**
     * Template fit: the maker's centre frame is ~square (840x880), so a tall
     * product rect would lose its top/bottom there. Pad the rect into a square
     * (8% margin) on plain white, so the whole product fits the centre with
     * nothing cut and no altered copy behind it. Returns a new square Bitmap.
     */
    private Bitmap squareFit(Bitmap rect) {
        try {
            int w = rect.getWidth(), h = rect.getHeight();
            int side = (int) (Math.max(w, h) * 1.08);
            if (side < 8) return rect;
            Bitmap out = Bitmap.createBitmap(side, side, Bitmap.Config.ARGB_8888);
            android.graphics.Canvas cv = new android.graphics.Canvas(out);
            // Simple plain backdrop: the photo stays whole and unaltered.
            cv.drawColor(0xFFFFFFFF);
            try {
                cv.drawBitmap(rect, (side - w) / 2f, (side - h) / 2f, null);
            } catch (Throwable t) { return rect; }
            return out;
        } catch (Throwable t) { return rect; }
    }

    private void savePng(Bitmap b, File f) throws Exception {
        FileOutputStream fos = new FileOutputStream(f);
        try { b.compress(Bitmap.CompressFormat.PNG, 100, fos); fos.flush(); }
        finally { try { fos.close(); } catch (Throwable ignored) {} }
    }

    private void saveJpg(Bitmap b, File f, int q) throws Exception {
        FileOutputStream fos = new FileOutputStream(f);
        try { b.compress(Bitmap.CompressFormat.JPEG, q, fos); fos.flush(); }
        finally { try { fos.close(); } catch (Throwable ignored) {} }
    }

    /** Copy a panel image into the shared Gallery (Pictures/AffVideo). */
    private void copyImageToGallery(File src, String mime) {
        android.content.ContentValues cv = new android.content.ContentValues();
        try {
            cv.put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, src.getName());
            cv.put(android.provider.MediaStore.Images.Media.MIME_TYPE, mime);
            if (Build.VERSION.SDK_INT >= 29) {
                cv.put(android.provider.MediaStore.Images.Media.RELATIVE_PATH,
                        android.os.Environment.DIRECTORY_PICTURES + "/AffVideo");
                cv.put(android.provider.MediaStore.Images.Media.IS_PENDING, 1);
            }
            android.net.Uri uri = getContentResolver().insert(
                    android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
            if (uri == null) return;
            java.io.InputStream in = new java.io.FileInputStream(src);
            java.io.OutputStream out = getContentResolver().openOutputStream(uri);
            try {
                byte[] buf = new byte[8192]; int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                out.flush();
            } finally {
                try { in.close(); } catch (Throwable ignored) {}
                try { if (out != null) out.close(); } catch (Throwable ignored) {}
            }
            if (Build.VERSION.SDK_INT >= 29) {
                android.content.ContentValues done = new android.content.ContentValues();
                done.put(android.provider.MediaStore.Images.Media.IS_PENDING, 0);
                try { getContentResolver().update(uri, done, null, null); }
                catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {}
    }

    private String isoNow() {
        try {
            return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).format(new Date());
        } catch (Throwable t) { return String.valueOf(System.currentTimeMillis()); }
    }

    private void toast(final String msg) {
        try {
            mainHandler.post(new Runnable() {
                @Override public void run() {
                    try { Toast.makeText(QuickPanelService.this, msg, Toast.LENGTH_SHORT).show(); }
                    catch (Throwable ignored) {}
                }
            });
        } catch (Throwable ignored) {}
    }
}
