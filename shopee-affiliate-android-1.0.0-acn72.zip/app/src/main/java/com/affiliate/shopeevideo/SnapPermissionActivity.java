package com.affiliate.shopeevideo;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Toast;

/**
 * Transparent helper: asks the system for screen-capture consent, then hands
 * the grant to FloatingService (which keeps the projection alive for one-tap
 * snaps). Shown only on first snap; finishes itself either way.
 */
public class SnapPermissionActivity extends Activity {

    private static final int REQ_SNAP = 8801;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        try {
            MediaProjectionManager mpm =
                    (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            if (mpm == null) { finish(); return; }
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ_SNAP);
        } catch (Throwable t) {
            try { finish(); } catch (Throwable ignored) {}
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        try {
            if (requestCode == REQ_SNAP && resultCode == RESULT_OK && data != null) {
                Intent i = new Intent(this, FloatingService.class);
                i.setAction("com.affiliate.shopeevideo.SNAP_GO");
                i.putExtra("rc", resultCode);
                i.putExtra("data", data);
                try {
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
                    else startService(i);
                } catch (Throwable t) {
                    Toast.makeText(this, "Could not reach the edge service (" + t + ")",
                            Toast.LENGTH_LONG).show();
                    try { finish(); } catch (Throwable ignored) {}
                    return;
                }
                Toast.makeText(this, "Snap ready — tap the camera button in the panel",
                        Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Screen capture not allowed", Toast.LENGTH_SHORT).show();
            }
        } catch (Throwable ignored) {}
        try { finish(); } catch (Throwable ignored) {}
    }
}
