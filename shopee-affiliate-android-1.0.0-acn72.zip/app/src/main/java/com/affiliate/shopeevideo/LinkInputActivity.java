package com.affiliate.shopeevideo;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Tiny link sheet opened by the edge card's "+ Link" button.
 *
 * It is a small translucent activity (NOT the maker): the user pastes/types
 * the Shopee link, taps Save, and is back where they were — the product is
 * queued in the background via QueueBox, no need to enter the app.
 * The field is prefilled from the clipboard when it holds a link.
 */
public class LinkInputActivity extends Activity {

    private EditText input;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        try {
            getWindow().setSoftInputMode(
                    WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
                            | WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        } catch (Throwable ignored) {}

        int dp8 = dp(8), dp12 = dp(12), dp16 = dp(16), dp24 = dp(24);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp24, dp24, dp24, dp24);
        try { root.setBackgroundColor(0x99000000); } catch (Throwable ignored) {}
        root.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF1B1B22);
        bg.setCornerRadius(dp(16));
        bg.setStroke(2, 0xFF3A3A48);
        card.setBackground(bg);
        card.setPadding(dp16, dp16, dp16, dp16);
        card.setOnClickListener(null);

        TextView title = new TextView(this);
        title.setText("Product link");
        title.setTextColor(0xFFF5F3EE);
        title.setTextSize(16);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, dp8);

        TextView hint = new TextView(this);
        hint.setText("Paste the Shopee link, then Save. It joins the cover "
                + "from + Cover — no need to open the app.");
        hint.setTextColor(0xFFA7A3B8);
        hint.setTextSize(13);
        hint.setPadding(0, 0, 0, dp8);

        input = new EditText(this);
        input.setHint("https://shopee.co.id/....");
        input.setHintTextColor(0xFF777777);
        input.setTextColor(0xFFF5F3EE);
        input.setTextSize(14);
        input.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_VARIATION_URI);
        input.setSingleLine(true);
        try {
            GradientDrawable ib = new GradientDrawable();
            ib.setColor(0xFF101016);
            ib.setCornerRadius(dp(10));
            ib.setStroke(2, 0xFF3A3A48);
            input.setBackground(ib);
        } catch (Throwable ignored) {}
        input.setPadding(dp12, dp12, dp12, dp12);
        String clip = clipboardLink();
        if (clip != null && clip.length() > 0) {
            input.setText(clip);
            try { input.setSelection(clip.length()); } catch (Throwable ignored) {}
        }

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        row.setPadding(0, dp12, 0, 0);
        LinearLayout.LayoutParams bw = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);

        Button cancel = new Button(this);
        cancel.setText("Cancel");
        cancel.setTextSize(14);
        cancel.setTextColor(0xFFF5F3EE);
        cancel.setBackgroundColor(Color.TRANSPARENT);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });

        Button save = new Button(this);
        save.setText("Save");
        save.setTextSize(15);
        save.setTextColor(0xFFFFFFFF);
        try {
            GradientDrawable sb = new GradientDrawable();
            sb.setColor(0xFFEE4D2D);
            sb.setCornerRadius(dp(10));
            save.setBackground(sb);
        } catch (Throwable ignored) {}
        save.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String link = "";
                try { link = input.getText().toString().trim(); }
                catch (Throwable ignored) {}
                if (link.length() == 0) {
                    toast("Paste a link first");
                    return;
                }
                String found = extractLink(link);
                if (found != null) link = found;
                String msg = QueueBox.saveLink(LinkInputActivity.this, link);
                toast(msg);
                finish();
            }
        });

        row.addView(cancel, bw);
        row.addView(save, bw);

        card.addView(title);
        card.addView(hint);
        card.addView(input);
        card.addView(row);
        root.addView(card);
        setContentView(root);

        try {
            input.requestFocus();
        } catch (Throwable ignored) {}
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private String clipboardLink() {
        try {
            ClipboardManager cm =
                    (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm == null || !cm.hasPrimaryClip()) return null;
            ClipData clip = cm.getPrimaryClip();
            if (clip == null || clip.getItemCount() == 0) return null;
            CharSequence cs = clip.getItemAt(0).coerceToText(this);
            if (cs == null) return null;
            return extractLink(cs.toString());
        } catch (Throwable t) {
            return null;
        }
    }

    private String extractLink(String text) {
        if (text == null) return null;
        try {
            java.util.regex.Matcher m = java.util.regex.Pattern.compile(
                    "https?://[^\\s'\"<>]+").matcher(text);
            if (m.find()) return m.group();
        } catch (Throwable ignored) {}
        return null;
    }

    private void toast(String msg) {
        try { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show(); }
        catch (Throwable ignored) {}
    }
}
