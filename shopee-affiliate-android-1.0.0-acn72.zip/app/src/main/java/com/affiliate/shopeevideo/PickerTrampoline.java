package com.affiliate.shopeevideo;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

/**
 * Transparent trampoline: a Service cannot use startActivityForResult, so the
 * floating panel's file picker launches here, the system picker runs on top,
 * and the chosen file comes back through a broadcast the service listens for.
 */
public class PickerTrampoline extends Activity {

    private static final int REQ_PICK = 2001;
    private int pickId = 0;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        try {
            pickId = getIntent().getIntExtra("id", 0);
            String[] mimes = getIntent().getStringArrayExtra("mime");
            Intent p = new Intent(Intent.ACTION_GET_CONTENT);
            p.addCategory(Intent.CATEGORY_OPENABLE);
            String type = "image/*";
            if (mimes != null && mimes.length > 0 && mimes[0] != null && mimes[0].length() > 0) {
                if (mimes[0].contains("video")) type = "video/*";
                else if (!mimes[0].contains("image")) type = "*/*";
            }
            p.setType(type);
            if ("*/*".equals(type)) p.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "video/*"});
            p.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(Intent.createChooser(p, "Pick file"), REQ_PICK);
        } catch (Throwable t) {
            sendResult(null);
        }
    }

    @Override
    protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        Uri uri = null;
        try {
            if (code == REQ_PICK && result == RESULT_OK && data != null) uri = data.getData();
        } catch (Throwable ignored) {}
        sendResult(uri);
    }

    private void sendResult(Uri uri) {
        try {
            if (uri != null) {
                try { grantUriPermission(getPackageName(), uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
                catch (Throwable ignored) {}
            }
            Intent b = new Intent("com.affiliate.shopeevideo.PICK_RESULT");
            b.setPackage(getPackageName());
            b.putExtra("id", pickId);
            b.putExtra("uri", uri == null ? "" : uri.toString());
            sendBroadcast(b);
        } catch (Throwable ignored) {}
        finish();
    }
}
