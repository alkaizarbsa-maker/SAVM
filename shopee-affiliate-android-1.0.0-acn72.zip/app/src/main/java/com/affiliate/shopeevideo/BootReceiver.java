package com.affiliate.shopeevideo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.provider.Settings;

/**
 * After a reboot, bring the edge stick back if the user had it on (i.e. the
 * overlay permission is granted — the service itself persists nothing).
 */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        try {
            if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())
                    && Settings.canDrawOverlays(ctx)) {
                Intent i = new Intent(ctx, FloatingService.class);
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i);
                else ctx.startService(i);
            }
        } catch (Throwable ignored) {}
    }
}
