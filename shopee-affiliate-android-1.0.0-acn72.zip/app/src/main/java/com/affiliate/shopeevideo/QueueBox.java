package com.affiliate.shopeevideo;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Background product queue for the edge quick card.
 *
 * Tapping "+ Cover" / "+ Link" on the floating card must NOT force the maker
 * open: the phone may be inside Shopee or a game. So covers and links are
 * paired here (files + prefs, no WebView needed) and the maker drains the
 * queue on its next resume via takeAll().
 *
 * Pairing works in either order:
 *  - cover first: the cover waits as a draft until a link arrives;
 *  - link first: the link waits as a draft (or fills the newest queued
 *    product that still has no link) until a cover arrives.
 */
public class QueueBox {

    public static final String PREFS = "edge_panel";
    private static final String KEY_QUEUE = "product_queue";
    private static final String KEY_DRAFT_LINK = "draft_link";
    private static final String KEY_DRAFT_COVER = "draft_cover";
    private static final String DRAFT_FILE = "draft_cover.jpg";
    private static final int MAX_BYTES = 8 * 1024 * 1024;

    public static class Item {
        public final File file;
        public final String link;
        Item(File f, String l) { file = f; link = l == null ? "" : l; }
    }

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static File queueDir(Context c) {
        File d = new File(c.getFilesDir(), "queue");
        try { if (!d.exists()) d.mkdirs(); } catch (Throwable ignored) {}
        return d;
    }

    private static JSONArray loadQueue(Context c) {
        try {
            String s = sp(c).getString(KEY_QUEUE, "[]");
            if (s == null || s.length() == 0) return new JSONArray();
            return new JSONArray(s);
        } catch (Throwable t) {
            return new JSONArray();
        }
    }

    private static void storeQueue(Context c, JSONArray q) {
        try { sp(c).edit().putString(KEY_QUEUE, q.toString()).apply(); }
        catch (Throwable ignored) {}
    }

    public static int queueCount(Context c) {
        try { return loadQueue(c).length(); } catch (Throwable t) { return 0; }
    }

    public static boolean hasDraftCover(Context c) {
        try {
            if (!sp(c).getBoolean(KEY_DRAFT_COVER, false)) return false;
            File f = new File(c.getCacheDir(), DRAFT_FILE);
            return f.exists() && f.length() > 0;
        } catch (Throwable t) { return false; }
    }

    public static String draftLink(Context c) {
        try {
            String s = sp(c).getString(KEY_DRAFT_LINK, "");
            return s == null ? "" : s.trim();
        } catch (Throwable t) { return ""; }
    }

    /** Short status line for the quick card, e.g. "2 saved • cover waiting for link". */
    public static String describe(Context c) {
        try {
            int n = queueCount(c);
            boolean dc = hasDraftCover(c);
            String dl = draftLink(c);
            String base = (n == 0) ? "nothing saved yet"
                    : (n + (n == 1 ? " product saved" : " products saved"));
            if (dc && dl.length() == 0) return base + " • cover waiting for link";
            if (!dc && dl.length() > 0) return base + " • link waiting for cover";
            if (dc) return base + " • cover + link ready";
            return base + " — no app needed";
        } catch (Throwable t) {
            return "";
        }
    }

    /**
     * A cover was picked from the card. Stash it; if a link is already
     * waiting, they pair into a queued product immediately.
     * Returns the toast message for the user.
     */
    public static String saveCover(Context c, byte[] data, String mime) {
        try {
            if (data == null || data.length == 0) return "Could not read that file";
            if (data.length > MAX_BYTES) return "That file is too big";
            File f = new File(c.getCacheDir(), DRAFT_FILE);
            FileOutputStream fos = new FileOutputStream(f);
            try {
                fos.write(data);
                fos.flush();
            } finally {
                try { fos.close(); } catch (Throwable ignored) {}
            }
            if (mime == null || mime.length() == 0) mime = "image/jpeg";
            sp(c).edit().putBoolean(KEY_DRAFT_COVER, true).apply();
            String dl = draftLink(c);
            if (dl.length() > 0) {
                return pairDraft(c, dl);
            }
            return "Cover saved — now tap + Link and paste the link";
        } catch (Throwable t) {
            return "Could not take that file";
        }
    }

    /**
     * A link was saved from the link sheet. Pairs with a waiting draft cover,
     * else fills the newest queued product missing a link, else waits for
     * the next cover. Returns the toast message for the user.
     */
    public static String saveLink(Context c, String link) {
        try {
            String lk = link == null ? "" : link.trim();
            if (lk.length() == 0) return "Paste a link first";
            if (hasDraftCover(c)) {
                sp(c).edit().putString(KEY_DRAFT_LINK, lk).apply();
                return pairDraft(c, lk);
            }
            JSONArray q = loadQueue(c);
            for (int i = q.length() - 1; i >= 0; i--) {
                try {
                    JSONObject o = q.getJSONObject(i);
                    String l = o.optString("l", "");
                    if (l == null || l.length() == 0) {
                        o.put("l", lk);
                        storeQueue(c, q);
                        return "Link added to product " + (i + 1)
                                + " (" + q.length() + " saved)";
                    }
                } catch (Throwable ignored) {}
            }
            sp(c).edit().putString(KEY_DRAFT_LINK, lk).apply();
            if (q.length() > 0) {
                return "Link saved — it will join the next cover";
            }
            return "Link saved — now tap + Cover";
        } catch (Throwable t) {
            return "Could not save that link";
        }
    }

    /** Move the draft cover + given link into the queue. Clears both drafts. */
    private static String pairDraft(Context c, String link) {
        try {
            File draft = new File(c.getCacheDir(), DRAFT_FILE);
            if (!draft.exists() || draft.length() == 0) {
                sp(c).edit().remove(KEY_DRAFT_COVER).apply();
                return "Cover expired — pick it again";
            }
            File dir = queueDir(c);
            String name = "q" + System.currentTimeMillis() + ".jpg";
            File dst = new File(dir, name);
            FileInputStream in = new FileInputStream(draft);
            try {
                FileOutputStream out = new FileOutputStream(dst);
                try {
                    byte[] buf = new byte[8192];
                    int r;
                    while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
                    out.flush();
                } finally {
                    try { out.close(); } catch (Throwable ignored) {}
                }
            } finally {
                try { in.close(); } catch (Throwable ignored) {}
            }
            try { draft.delete(); } catch (Throwable ignored) {}
            JSONArray q = loadQueue(c);
            JSONObject o = new JSONObject();
            o.put("f", name);
            o.put("l", link == null ? "" : link);
            q.put(o);
            storeQueue(c, q);
            try {
                sp(c).edit().remove(KEY_DRAFT_COVER)
                        .remove(KEY_DRAFT_LINK).apply();
            } catch (Throwable ignored) {}
            int n = q.length();
            return "Product saved (" + n + ") — link attached, no need to open app";
        } catch (Throwable t) {
            return "Could not save that product";
        }
    }

    /**
     * Drain everything for the maker: queued products plus any half-finished
     * draft (cover waiting without a link ships with its empty link so
     * nothing is ever lost). Clears prefs entries; files are deleted by the
     * caller after reading via deleteItem().
     */
    public static List<Item> takeAll(Context c) {
        List<Item> out = new ArrayList<Item>();
        try {
            JSONArray q = loadQueue(c);
            File dir = queueDir(c);
            for (int i = 0; i < q.length(); i++) {
                try {
                    JSONObject o = q.getJSONObject(i);
                    String f = o.optString("f", "");
                    String l = o.optString("l", "");
                    if (f == null || f.length() == 0) continue;
                    if (f.contains("/") || f.contains("\\") || f.contains("..")) continue;
                    File file = new File(dir, f);
                    if (file.exists() && file.length() > 0) out.add(new Item(file, l));
                } catch (Throwable ignored) {}
            }
            try { sp(c).edit().remove(KEY_QUEUE).apply(); }
            catch (Throwable ignored) {}
            if (hasDraftCover(c)) {
                try {
                    File draft = new File(c.getCacheDir(), DRAFT_FILE);
                    if (draft.exists() && draft.length() > 0
                            && draft.length() <= MAX_BYTES) {
                        out.add(new Item(draft, draftLink(c)));
                    }
                } catch (Throwable ignored) {}
                try {
                    sp(c).edit().remove(KEY_DRAFT_COVER)
                            .remove(KEY_DRAFT_LINK).apply();
                } catch (Throwable ignored) {}
            } else {
                try { sp(c).edit().remove(KEY_DRAFT_LINK).apply(); }
                catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {}
        return out;
    }

    public static byte[] readItem(Item it) {
        if (it == null || it.file == null) return null;
        try {
            long len = it.file.length();
            if (len <= 0 || len > MAX_BYTES) return null;
            FileInputStream in = new FileInputStream(it.file);
            try {
                java.io.ByteArrayOutputStream bos =
                        new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int r;
                while ((r = in.read(buf)) > 0) bos.write(buf, 0, r);
                return bos.toByteArray();
            } finally {
                try { in.close(); } catch (Throwable ignored) {}
            }
        } catch (Throwable t) {
            return null;
        }
    }

    public static void deleteItem(Item it) {
        try { if (it != null && it.file != null) it.file.delete(); }
        catch (Throwable ignored) {}
    }
}
