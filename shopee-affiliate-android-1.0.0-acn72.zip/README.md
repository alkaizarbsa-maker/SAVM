# Shopee Affiliate Video Maker — Android app

Batch maker for Shopee affiliate videos in a WebView wrapper (same bundle
style as LitReader): one background video × N products → one fixed-design
9:16 video per product, rendered on-device with canvas + MediaRecorder.

- **From anywhere**: share a photo from Shopee/gallery/browser straight
  into the app (it lands in Products with its link); shared text/links
  paste into the link field; tapping Shopee links can open the app.
- **Edge tab**: a small tab right on the screen edge, visible from any
  app — tap it for a game-space-style quick card with big buttons: snap
  the screen (opens the maker with the trim tool), open the full app,
  hide back to the tab. **+ Cover + Link queue products without opening
  the app**: pick a cover, paste its link in the little sheet
  (prefilled from your clipboard), and they pair automatically — the
  card counts what is saved, in either order. Open Full whenever you
  want to render. It can be dragged up/down and moved
  left/right from the app's App tab (position persists). Toggle it in
  the app's App tab; needs the "display over other apps" permission
  once. Restarts after reboot automatically.

- Fixed **510 dp** screen on every device (`width=510` viewport + overview
  scaling, enforced again after every page load).
- **Immersive mode ON** (sticky fullscreen, swipe to reveal system bars),
  edge-to-edge behind transparent system bars.
- One shared signing key (`litreader-debug.p12`, committed in the repo — do
  not delete it), so every new APK installs over the old one as an update:
  no uninstall, data carries over. Rebuilds are always versioned higher.

## Build it in the cloud (recommended — nothing to install)

1. Create a free GitHub account and a new empty repository.
2. Upload the bundle `.zip` (e.g. `shopee-affiliate-android-1.0.0-xxxxx.zip`)
   to the repository's root, exactly as downloaded.
3. Copy `github-workflows/build-apk.yml` from inside the zip to
   `.github/workflows/build-apk.yml` in the repo and commit
   (GitHub only runs workflows from `.github/workflows/`).
4. Open the repository's **Actions** tab → **Build Affiliate APK** → the run
   starts by itself (or Run workflow). Wait ~5–10 minutes.
5. Download the `affiliate-apk` artifact, copy it to the phone, tap it to
   install (allow “install unknown apps” once).

## Updating (new version, same install)

Never delete the repository — GitHub overwrites files happily, and a fresh
repo is exactly what breaks updates (new repo, new run numbers).

1. In your repo, open `app/src/main/assets/www/index.html`, delete its
   contents, paste in the new standalone file (or Add file → Upload files
   and overwrite it), and commit. The workflow rebuilds by itself.
2. Download the new `affiliate-apk` artifact and tap it on the phone. It
   installs as an update over the existing app — same app, same data.

If the app on your phone came from anywhere else, those carry a different
signature, so Android refuses with “conflicting package”: uninstall once,
install the repo build, and from that build on the step above just works.

## Build it locally

Android Studio → Open → this folder (the unzipped bundle) → let it sync
(it will offer to set up the Gradle wrapper if you have none) → Run.
Same APK as above.

## Point it at a different address

The app opens its bundled copy (`app/src/main/assets/www/index.html`).
To wrap a different address instead, add one manifest entry and it wins
over the bundle:
`<meta-data android:name="com.affiliate.shopeevideo.URL"
android:value="https://perchance.org/yourfork" />`.

## Use it as a converter template

An in-browser APK patcher cannot inject Java into a prebuilt template —
a JS bridge has to be *compiled in*. This project already is, so it works
as a drop-in template: build once, use the resulting APK as the
converter's new `template.apk`. Per conversion the converter only patches
what it already patches (package name, icon, label) plus `<meta-data>`
entries, which is exactly what in-browser patchers can do. Flags, all
optional, all default `false` unless set:
`com.affiliate.shopeevideo.URL` (wrapped address),
`com.affiliate.shopeevideo.IMMERSIVE`, `DARK_MODE`, `EDGE_TO_EDGE`,
`PULL_REFRESH` (unused in this build), `DESKTOP_SITE`.
Values accept `true`/`false` or `1`/`0`.

## Play Store bundle (.aab)

Google Play does not take APKs — it takes an Android App Bundle. Copy
`github-workflows/build-bundle.yml` to `.github/workflows/` alongside the
APK workflow, then run **Build Affiliate Bundle** from the Actions tab. The
`affiliate-bundle` artifact holds `app-release.aab`, signed with the same
committed key, so every rebuild uploads as an update of the last. Upload it
in Play Console (Create app → Production → Create new release). Play App
Signing re-signs for users with Google's own key, so the committed key's
"debug" nature never reaches devices — but it stays the permanent *upload*
key for this app, so keep `litreader-debug.p12` in the repo.

## Release signing (optional)

For a Play-style signed release: generate your own keystore, add it as a
GitHub Actions secret plus `SIGNING_*` variables and a `signingConfigs`
block — any standard “Android sign APK in GitHub Actions” guide applies
unchanged. (A release-signed app is a different signature from these
builds, so switching between them costs one uninstall.)
